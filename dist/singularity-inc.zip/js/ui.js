/* UI layer -> window.GAME_UI. Builds DOM, wires events, updates each frame.
   Pure presentation on top of window.GAME. */
(function () {
  'use strict';

  var G = window.GAME, C = window.GAME_CONFIG, FMT = window.GAME_FMT;
  var t = function (k, v) { return window.GAME_I18N.t(k, v); };
  var $ = function (id) { return document.getElementById(id); };
  var fmt = FMT.fmt;

  var currentTab = 'company';
  var genRefs = {};      // id -> {el, cost, count, sub, mbar, qty}
  var built = false;
  var ICON = window.GAME_ICONS || {};
  var SW = ' fill="none" stroke="currentColor" stroke-width="1.75" stroke-linecap="round" stroke-linejoin="round"';
  var EXTRA = {
    ic_check: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"><path d="M20 6 9 17l-5-5"/></svg>',
    ic_tech: '<svg viewBox="0 0 24 24"' + SW + '><circle cx="12" cy="5" r="2.2"/><circle cx="5.5" cy="18" r="2.2"/><circle cx="18.5" cy="18" r="2.2"/><path d="M12 7.2v3.3M12 10.5 6.4 16M12 10.5 17.6 16"/></svg>',
    ic_artifact: '<svg viewBox="0 0 24 24"' + SW + '><path d="M6 3h12l3 5-9 13L3 8z"/><path d="M3 8h18M9 3 7.5 8 12 21 16.5 8 15 3"/></svg>',
    ic_core: '<svg viewBox="0 0 24 24"' + SW + '><circle cx="12" cy="12" r="2.4" fill="currentColor"/><ellipse cx="12" cy="12" rx="9" ry="3.6"/><ellipse cx="12" cy="12" rx="9" ry="3.6" transform="rotate(60 12 12)"/><ellipse cx="12" cy="12" rx="9" ry="3.6" transform="rotate(120 12 12)"/></svg>',
    nav_singularity: '<svg viewBox="0 0 24 24"' + SW + '><circle cx="12" cy="12" r="3" fill="currentColor"/><path d="M12 3a9 9 0 1 1-7 3.3"/><path d="M12 3a9 9 0 0 1 7 3.3" opacity="0.5"/></svg>',
    ic_lock: '<svg viewBox="0 0 24 24"' + SW + '><rect x="5" y="11" width="14" height="9" rx="2"/><path d="M8 11V8a4 4 0 0 1 8 0v3"/></svg>',
    ic_world: '<svg viewBox="0 0 24 24"' + SW + '><circle cx="12" cy="12" r="9"/><path d="M3 12h18M12 3c2.6 2.5 2.6 15.5 0 18M12 3c-2.6 2.5-2.6 15.5 0 18"/></svg>',
    ic_market: '<svg viewBox="0 0 24 24"' + SW + '><path d="M4 19V5M4 19h16"/><path d="M7 15l3-4 3 2 4-6"/></svg>',
    ic_trust: '<svg viewBox="0 0 24 24"' + SW + '><path d="M12 3l7 3v5c0 4.5-3 7.5-7 9-4-1.5-7-4.5-7-9V6z"/><path d="M9 12l2 2 4-4"/></svg>'
  };
  function ic(key) { return EXTRA[key] || ICON[key] || ''; }

  // ---------- helpers ----------
  function el(tag, cls, html) {
    var e = document.createElement(tag);
    if (cls) e.className = cls;
    if (html !== undefined) e.innerHTML = html;
    return e;
  }
  function toast(msg, kind) {
    var root = $('toastRoot');
    var e = el('div', 'toast' + (kind ? ' ' + kind : ''), msg);
    root.appendChild(e);
    setTimeout(function () { if (e.parentNode) e.parentNode.removeChild(e); }, 3000);
  }
  function floatText(x, y, txt, cls) {
    var e = el('div', 'float' + (cls ? ' ' + cls : ''), txt);
    e.style.left = (x - 12) + 'px';
    e.style.top = (y - 20) + 'px';
    $('fxRoot').appendChild(e);
    setTimeout(function () { if (e.parentNode) e.parentNode.removeChild(e); }, 1100);
  }

  // ---------- odometer: eased rolling counter with pop on magnitude change ----
  var odoState = {};
  function setOdometer(el, target) {
    if (!el) return;
    var id = el.id || 'odo';
    var st = odoState[id] || (odoState[id] = { disp: target, lastLen: -1 });
    var d = st.disp + (target - st.disp) * 0.22;
    if (!isFinite(d)) d = target;
    if (Math.abs(target - d) < target * 0.0015 + 0.5) d = target;
    st.disp = d;
    var str = fmt(d);
    el.textContent = str;
    if (str.length !== st.lastLen) {
      st.lastLen = str.length;
      el.classList.remove('bump'); void el.offsetWidth; el.classList.add('bump');
    }
  }

  // ---------- static labels (i18n) ----------
  function renderStatic() {
    document.documentElement.lang = window.GAME_I18N.getLang();
    $('brandName').textContent = t('game_title');
    $('brandIcon').innerHTML = ic('ic_insight');
    $('tapIcon').innerHTML = ic('ic_brain');
    $('tapLabel').textContent = t('tap_button');
    $('tapHint').textContent = t('tap_hint');
    // nav icons (replace emoji with inline SVG)
    var navIcons = { company: 'nav_company', upgrades: 'nav_upgrades', research: 'nav_research', singularity: 'nav_singularity', alignment: 'nav_alignment', world: 'ic_world', stats: 'nav_stats', achievements: 'nav_achievements', settings: 'nav_settings' };
    $('trustHud').querySelector('.thi').innerHTML = ic('ic_trust');
    var navBtns = $('tabbar').children;
    for (var ni = 0; ni < navBtns.length; ni++) {
      var tabKey = navBtns[ni].dataset.tab;
      var tiEl = navBtns[ni].querySelector('.ti');
      if (tiEl && navIcons[tabKey]) tiEl.innerHTML = ic(navIcons[tabKey]);
    }
    // nav
    $('nav_company').textContent = t('tab_company');
    $('nav_upgrades').textContent = t('tab_upgrades');
    $('nav_research').textContent = t('tab_research');
    $('nav_singularity').textContent = t('tab_singularity');
    $('nav_world').textContent = t('tab_world');
    $('worldNewsTitle').textContent = t('world_news_title');
    $('worldMarketTitle').textContent = t('world_market_title');
    $('newsFlavorTitle').textContent = t('news_flavor_title');
    $('marketIntro').textContent = t('market_intro');
    buildMarket();
    // research-tab extras
    $('artifactsTitle').textContent = t('artifacts_title');
    $('techTitle').textContent = t('tech_title');
    // singularity tab
    $('singTitle').textContent = t('singularity_title');
    $('singDesc').textContent = t('singularity_desc', { p: Math.round(C.SINGULARITY.CORE_BONUS * 100) });
    $('metaTitle').textContent = t('meta_title');
    buildArtifacts(); buildTech(); buildMeta();
    $('nav_alignment').textContent = t('tab_alignment');
    $('nav_stats').textContent = t('tab_stats');
    $('nav_achievements').textContent = t('tab_achievements');
    $('nav_settings').textContent = t('tab_settings');
    // upgrades + autopilot
    $('upgradesTitle').textContent = t('upgrades_title');
    $('managersTitle').textContent = t('managers_title');
    $('autopilotHdr').textContent = t('autopilot_title');
    $('apReserveLabel').textContent = t('ap_reserve');
    $('apModeLabel').textContent = t('ap_mode');
    $('apGensLabel').textContent = t('ap_gens');
    var apo = $('apOnSeg').children; apo[0].textContent = t('on'); apo[1].textContent = t('off');
    var apm = $('apModeSeg').children; apm[0].textContent = t('ap_mode_roi'); apm[1].textContent = t('ap_mode_milestone');
    buildAutopilot();
    // research
    $('researchTitle').textContent = t('research_title');
    $('researchDesc').textContent = t('research_desc', { p: (C.PRESTIGE.BONUS * 100) });
    $('prestigeUpTitle').textContent = t('prestige_upgrades_title');
    // alignment
    $('alignTitle').textContent = t('alignment_title');
    $('alignIntro').textContent = t('alignment_intro');
    $('alignLabel').textContent = t('alignment_label');
    $('alignTip').innerHTML = '<span class="ticon">' + ic('ic_insight') + '</span><span>' + t('tip_insight') + '</span>';
    $('researchTip').innerHTML = '<span class="ticon">' + ic('ic_bolt') + '</span><span>' + t('tip_overclock') + '</span>';
    // stats
    $('statsTitle').textContent = t('stats_title');
    $('achTitle').textContent = t('achievements_title');
    // settings
    $('settingsTitle').textContent = t('settings_title');
    $('langLabel').textContent = t('language');
    $('soundLabel').textContent = t('sound');
    $('musicLabel').textContent = t('music');
    var msg = $('musicSeg').children; msg[0].textContent = t('on'); msg[1].textContent = t('off');
    $('adBoostLabel').textContent = t('ad_boost');
    $('adCashLabel').textContent = t('ad_cash');
    $('adBoostBtn').textContent = t('ad_boost');
    $('adCashBtn').textContent = t('ad_cash');
    $('cosmeticsTitle').textContent = t('cosmetics_title');
    $('cosOrbLabel').textContent = t('cosmetics_orb');
    $('cosThemeLabel').textContent = t('cosmetics_theme');
    buildCosmetics();
    $('saveBtn').textContent = t('save_now');
    $('resetBtn').textContent = t('reset_progress');
    $('creditsTxt').textContent = t('credits');
    $('versionTxt').textContent = t('version', { v: '1.0' });
    $('riskMiniLabel').innerHTML = '<span>' + t('risk_label') + '</span><span id="riskMiniPct"></span>';
    // sound seg labels
    var ssg = $('soundSeg').children;
    ssg[0].textContent = t('on'); ssg[1].textContent = t('off');
    // rebuild dynamic lists that contain names
    buildGenerators();
    buildUpgrades();
    buildManagers();
    buildPrestigeUpgrades();
    buildAchievements();
  }

  // ---------- generators ----------
  function buildGenerators() {
    var list = $('genList');
    list.innerHTML = '';
    genRefs = {};
    var classOf = function (id) { for (var k in C.GEN_CLASS) if (C.GEN_CLASS[k].indexOf(id) >= 0) return k; return 'low'; };
    C.GENERATORS.forEach(function (g, gi) {
      var card = el('div', 'card locked');
      card.dataset.cls = classOf(g.id);
      card.style.animationDelay = (Math.min(gi, 12) * 32) + 'ms';
      card.innerHTML =
        '<div class="iconwrap">' + ic('gen_' + g.id) + '</div>' +
        '<div class="info">' +
          '<div class="name">' + t('g_' + g.id) + '</div>' +
          '<div class="desc">' + t('g_' + g.id + '_d') + '</div>' +
          '<div class="sub"></div>' +
          '<div class="milestoneBar"><div></div></div>' +
        '</div>' +
        '<div class="right">' +
          '<div class="cost">0</div>' +
          '<div class="count"></div>' +
          '<div class="qty"></div>' +
        '</div>' +
        '<div class="ownedBadge hidden">0</div>';
      card.addEventListener('click', function (e) {
        if (G.buyGen(g.id)) {
          window.GAME_AUDIO.buy();
          window.GAME_FX.cardFlash(card);
          var r = card.getBoundingClientRect();
          window.GAME_FX.buyBurst(e.clientX || (r.left + r.width / 2), e.clientY || (r.top + r.height / 2));
        }
      });
      list.appendChild(card);
      genRefs[g.id] = {
        el: card,
        cost: card.querySelector('.cost'),
        count: card.querySelector('.count'),
        sub: card.querySelector('.sub'),
        mbar: card.querySelector('.milestoneBar > div'),
        qty: card.querySelector('.qty'),
        badge: card.querySelector('.ownedBadge')
      };
    });
  }

  function updateGenerators() {
    var s = G.state;
    C.GENERATORS.forEach(function (g) {
      var r = genRefs[g.id];
      if (!r) return;
      var owned = s.gens[g.id];
      var qty = G.buyQty(g.id);
      var cost = G.genCostCumulative(g.id, qty);
      var unlockedByPrev = true;
      // soft lock: show generator only if previous owned or it's the first or already owned
      var idx = C.GENERATORS.indexOf(g);
      if (idx > 0 && owned === 0 && s.gens[C.GENERATORS[idx - 1].id] === 0 && s.cash < g.baseCost * 0.5) {
        r.el.classList.add('hidden');
        return;
      }
      r.el.classList.remove('hidden');
      var afford = s.cash >= cost && qty >= 1;
      r.el.classList.toggle('affordable', afford);
      r.el.classList.toggle('locked', !afford);
      r.cost.textContent = fmt(cost);
      r.cost.classList.toggle('cant', !afford);
      r.count.textContent = owned;
      r.qty.textContent = owned > 0 ? ('+' + qty) : (s.buyMode === 'max' ? '' : 'x' + (s.buyMode));
      r.sub.textContent = owned > 0 ? (fmt(G.genOutput(g.id) * G.globalMult()) + '/sec') : t('produces', { v: fmt(g.baseOut * G.globalMult()) });
      if (owned > 0) { r.badge.classList.remove('hidden'); r.badge.textContent = owned; }
      else r.badge.classList.add('hidden');
      var msLevel = owned >= 200 ? 3 : owned >= 100 ? 2 : owned >= 25 ? 1 : 0;
      r.el.classList.toggle('ms1', msLevel === 1);
      r.el.classList.toggle('ms2', msLevel === 2);
      r.el.classList.toggle('ms3', msLevel === 3);
      var nm = G.nextMilestone(owned);
      if (nm) { r.mbar.style.width = Math.min(100, (owned / nm) * 100) + '%'; r.mbar.parentNode.style.display = ''; }
      else { r.mbar.parentNode.style.display = 'none'; }
    });
  }

  // ---------- upgrades ----------
  var upBuilt = false;
  function buildUpgrades() {
    var list = $('upgradeList');
    list.innerHTML = '';
    C.UPGRADES.forEach(function (u) {
      var card = el('div', 'card locked');
      card.dataset.uid = u.id;
      card.innerHTML =
        '<div class="iconwrap">' + ic('ic_upgrade') + '</div>' +
        '<div class="info"><div class="name">' + t(u.id) + '</div>' +
        '<div class="desc">' + t(u.id + '_d') + '</div></div>' +
        '<div class="right"><div class="cost">' + fmt(u.cost) + '</div></div>';
      card.addEventListener('click', function () { if (G.buyUpgrade(u.id)) window.GAME_AUDIO.buy(); });
      list.appendChild(card);
    });
  }
  function updateUpgrades() {
    var s = G.state;
    var nodes = $('upgradeList').children;
    var anyVisible = false;
    for (var i = 0; i < nodes.length; i++) {
      var card = nodes[i];
      var u = C.UPGRADES[i];
      if (s.upgrades[u.id]) { card.classList.add('hidden'); continue; }
      var unlocked = !u.unlock || s.gens[u.unlock.gen] >= u.unlock.count;
      if (!unlocked) { card.classList.add('hidden'); continue; }
      card.classList.remove('hidden');
      anyVisible = true;
      var afford = s.cash >= u.cost;
      card.classList.toggle('affordable', afford);
      card.classList.toggle('locked', !afford);
      card.querySelector('.cost').classList.toggle('cant', !afford);
    }
    var ue = $('upgradeEmpty');
    if (ue) { ue.classList.toggle('hidden', anyVisible); if (!anyVisible) ue.innerHTML = '<div class="es-icon">' + ic('ic_upgrade') + '</div>' + t('no_upgrades'); }
  }

  // ---------- managers ----------
  function buildManagers() {
    var list = $('managerList');
    list.innerHTML = '';
    C.MANAGERS.forEach(function (m) {
      var card = el('div', 'card locked');
      card.dataset.mid = m.id;
      card.innerHTML =
        '<div class="iconwrap">' + ic('ic_manager') + '</div>' +
        '<div class="info"><div class="name">' + t(m.id) + '</div>' +
        '<div class="desc">' + t('manager_auto', { name: t('g_' + m.gen) }) + '</div></div>' +
        '<div class="right"><div class="cost">' + fmt(m.cost) + '</div></div>';
      card.addEventListener('click', function () { if (G.buyManager(m.id)) window.GAME_AUDIO.buy(); });
      list.appendChild(card);
    });
  }
  function updateManagers() {
    var s = G.state;
    var nodes = $('managerList').children;
    var anyVis = false;
    for (var i = 0; i < nodes.length; i++) {
      var card = nodes[i];
      var m = C.MANAGERS[i];
      if (s.managers[m.id] || s.gens[m.gen] >= 1) anyVis = true;
      if (s.managers[m.id]) {
        card.classList.remove('locked', 'affordable');
        card.querySelector('.right').innerHTML = '<div class="bought">✓ ' + t('bought') + '</div>';
        card.onclick = null;
        continue;
      }
      var unlocked = s.gens[m.gen] >= 1;
      card.classList.toggle('hidden', !unlocked);
      var afford = s.cash >= m.cost;
      card.classList.toggle('affordable', afford);
      card.classList.toggle('locked', !afford);
    }
    var me = $('managerEmpty');
    if (me) { me.classList.toggle('hidden', anyVis); if (!anyVis) me.innerHTML = '<div class="es-icon">' + ic('ic_manager') + '</div>' + t('no_managers'); }
  }

  // ---------- prestige upgrades ----------
  function buildPrestigeUpgrades() {
    var list = $('prestigeUpList');
    list.innerHTML = '';
    C.PRESTIGE.upgrades.forEach(function (p) {
      var card = el('div', 'pcard');
      card.dataset.pid = p.id;
      var desc = (p.type === 'startCash') ? t(p.id + '_d', { v: fmt(p.value) }) : t(p.id + '_d');
      card.innerHTML =
        '<div class="picon">' + ic('ic_rp') + '</div>' +
        '<div class="info"><div class="name">' + t(p.id) + '</div><div class="desc">' + desc + '</div></div>' +
        '<button>' + t('rp_cost', { n: p.cost }) + '</button>';
      card.querySelector('button').addEventListener('click', function () {
        if (G.buyPrestigeUpgrade(p.id)) { window.GAME_AUDIO.buy(); }
      });
      list.appendChild(card);
    });
  }
  function updatePrestigeUpgrades() {
    var s = G.state;
    var nodes = $('prestigeUpList').children;
    for (var i = 0; i < nodes.length; i++) {
      var card = nodes[i];
      var p = C.PRESTIGE.upgrades[i];
      var btn = card.querySelector('button');
      if (s.prestigeUpgrades[p.id]) {
        card.classList.add('owned');
        btn.textContent = '✓ ' + t('bought');
        btn.disabled = true;
      } else {
        card.classList.remove('owned');
        btn.textContent = t('rp_cost', { n: p.cost });
        btn.disabled = s.rp < p.cost;
      }
    }
  }

  // ---------- autopilot ----------
  function buildAutopilot() {
    var list = $('apGenToggles'); if (!list) return; list.innerHTML = '';
    C.GENERATORS.forEach(function (g) {
      var chip = el('button', 'ap-chip'); chip.dataset.gid = g.id;
      chip.innerHTML = '<span class="api">' + ic('gen_' + g.id) + '</span><span class="apn">' + t('g_' + g.id) + '</span><span class="apdot"></span>';
      chip.addEventListener('click', function () {
        var on = !G.state.autopilot.gens[g.id];
        G.toggleAutopilotGen(g.id, on); window.GAME_AUDIO.buy(); updateAutopilot();
      });
      list.appendChild(chip);
    });
  }
  function apStatusText() {
    var s = G.state, st = G.apStatus();
    if (!s.autopilot.on) return t('ap_status_off');
    var anyGen = false; for (var k in s.autopilot.gens) if (s.autopilot.gens[k]) anyGen = true;
    if (!anyGen) return t('ap_status_nogens');
    if (st.kind === 'buy') return t('ap_status_buy', { name: t('g_' + st.id), mode: t(st.mode === 'milestone' ? 'ap_mode_milestone_short' : 'ap_mode_roi_short') });
    if (st.kind === 'reserve') return t('ap_status_reserve');
    return t('ap_status_idle');
  }
  function updateAutopilot() {
    var s = G.state, unlocked = G.autopilotUnlocked();
    $('autopilotLocked').classList.toggle('hidden', unlocked);
    $('autopilotPanel').classList.toggle('hidden', !unlocked);
    if (!unlocked) { $('autopilotLocked').innerHTML = '<div class="es-icon">' + ic('ic_bolt') + '</div>' + t('autopilot_locked'); return; }
    // on/off seg
    var onb = $('apOnSeg').children; onb[0].classList.toggle('on', s.autopilot.on); onb[1].classList.toggle('on', !s.autopilot.on);
    // status
    var stEl = $('apStatus'); stEl.textContent = apStatusText();
    stEl.classList.toggle('live', s.autopilot.on && G.apStatus().kind === 'buy');
    // reserve
    var pct = Math.round(s.autopilot.reserve * 100);
    if (document.activeElement !== $('apReserve')) $('apReserve').value = pct;
    $('apReserveKeeps').textContent = t('ap_reserve_keeps', { p: pct, v: fmt(s.cash * s.autopilot.reserve) });
    // mode seg
    var mb = $('apModeSeg').children; mb[0].classList.toggle('on', s.autopilot.mode === 'roi'); mb[1].classList.toggle('on', s.autopilot.mode === 'milestone');
    // gen toggles
    var chips = $('apGenToggles').children;
    for (var i = 0; i < chips.length; i++) {
      var gid = chips[i].dataset.gid;
      chips[i].classList.toggle('hidden', s.gens[gid] === 0);
      chips[i].classList.toggle('on', !!s.autopilot.gens[gid]);
    }
  }

  // ---------- tech tree ----------
  function techDesc(tk) { return t('tech_cat_' + tk.cat) + ' ×' + tk.mult; }
  function buildTech() {
    var list = $('techList'); list.innerHTML = '';
    C.TECH.forEach(function (tk) {
      var card = el('div', 'card locked'); card.dataset.tid = tk.id;
      card.innerHTML =
        '<div class="iconwrap">' + ic('ic_tech') + '</div>' +
        '<div class="info"><div class="name">' + t(tk.id) + '</div><div class="desc">' + techDesc(tk) + '</div><div class="sub req"></div></div>' +
        '<div class="right"><button class="minibtn">' + t('rp_cost', { n: tk.cost }) + '</button></div>';
      card.querySelector('button').addEventListener('click', function () { if (G.buyTech(tk.id)) window.GAME_AUDIO.buy(); });
      list.appendChild(card);
    });
  }
  function updateTech() {
    var s = G.state, nodes = $('techList').children;
    for (var i = 0; i < nodes.length; i++) {
      var tk = C.TECH[i], card = nodes[i], btn = card.querySelector('button'), req = card.querySelector('.req');
      if (s.tech[tk.id]) { card.classList.add('owned-tech'); card.classList.remove('locked'); btn.textContent = '✓ ' + t('bought'); btn.disabled = true; req.textContent = ''; continue; }
      var ok = G.techReqMet(tk);
      if (!ok) {
        card.classList.add('locked'); btn.disabled = true; btn.textContent = t('rp_cost', { n: tk.cost });
        if (tk.req.tech) req.textContent = t('tech_locked_tech', { name: t(tk.req.tech) });
        else if (tk.req.gen) req.textContent = t('tech_locked_gen', { n: tk.req.count, name: t('g_' + tk.req.gen) });
      } else {
        req.textContent = '';
        var afford = s.rp >= tk.cost;
        card.classList.toggle('locked', !afford); card.classList.toggle('affordable', afford);
        btn.disabled = !afford; btn.textContent = t('rp_cost', { n: tk.cost });
      }
    }
  }

  // ---------- artifacts ----------
  function artDesc(a) { return a.effect.type === 'gamble' ? t('art_gamble') : (t('art_' + a.effect.type) + ' ×' + a.effect.value); }
  function buildArtifacts() {
    var list = $('artifactList'); list.innerHTML = '';
    C.ARTIFACTS.forEach(function (a) {
      var card = el('div', 'card'); card.dataset.arid = a.id;
      var tags = a.tags.map(function (tg) { return '<span class="tagchip">' + t('tag_' + tg) + '</span>'; }).join('');
      card.innerHTML =
        '<div class="iconwrap">' + ic('ic_artifact') + '</div>' +
        '<div class="info"><div class="name">' + t(a.id) + '</div><div class="desc">' + artDesc(a) + '</div><div class="tags">' + tags + '</div></div>' +
        '<div class="right"><button class="minibtn"></button></div>';
      card.querySelector('button').addEventListener('click', function () {
        if (G.state.artifactsEquipped.indexOf(a.id) >= 0) G.unequipArtifact(a.id);
        else if (G.equipArtifact(a.id)) window.GAME_AUDIO.buy();
        else window.GAME_AUDIO.buy();
      });
      list.appendChild(card);
    });
  }
  function updateArtifacts() {
    var s = G.state, nodes = $('artifactList').children, anyOwned = false;
    for (var i = 0; i < nodes.length; i++) {
      var a = C.ARTIFACTS[i], card = nodes[i], btn = card.querySelector('button');
      var owned = !!s.artifactsOwned[a.id];
      card.classList.toggle('hidden', !owned);
      if (owned) anyOwned = true;
      var eq = s.artifactsEquipped.indexOf(a.id) >= 0;
      card.classList.toggle('equipped', eq);
      card.classList.toggle('affordable', eq);
      btn.textContent = eq ? t('unequip') : t('equip');
      btn.disabled = !eq && s.artifactsEquipped.length >= C.ARTIFACT_SLOTS;
    }
    $('artSynergy').textContent = anyOwned
      ? t('equipped_label', { n: s.artifactsEquipped.length, m: C.ARTIFACT_SLOTS }) + '  ·  ' + t('synergy_label') + ' ×' + G.artifactSynergyMult().toFixed(2)
      : t('artifacts_empty');
  }

  // ---------- core (meta) upgrades ----------
  var META_KEY = { globalMult: 'meta_global', rpGain: 'meta_rp', tapMult: 'meta_tap', riskMult: 'meta_risk', offlineCap: 'meta_offline', coreGain: 'meta_core' };
  function metaDesc(mu) {
    var lbl = t(META_KEY[mu.type] || 'meta_global');
    if (mu.type === 'offlineCap') return lbl + ' +' + mu.value + 'h';
    return lbl + ' ×' + mu.value;
  }
  function buildMeta() {
    var list = $('metaList'); list.innerHTML = '';
    C.SINGULARITY.meta.forEach(function (mu) {
      var card = el('div', 'pcard'); card.dataset.mid = mu.id;
      card.innerHTML =
        '<div class="picon">' + ic('ic_core') + '</div>' +
        '<div class="info"><div class="name">' + t(mu.id) + '</div><div class="desc">' + metaDesc(mu) + '</div></div>' +
        '<button>' + t('cores_cost', { n: mu.cost }) + '</button>';
      card.querySelector('button').addEventListener('click', function () { if (G.buyMeta(mu.id)) window.GAME_AUDIO.prestige(); });
      list.appendChild(card);
    });
  }
  function updateMeta() {
    var s = G.state, nodes = $('metaList').children;
    for (var i = 0; i < nodes.length; i++) {
      var mu = C.SINGULARITY.meta[i], card = nodes[i], btn = card.querySelector('button');
      if (s.meta[mu.id]) { card.classList.add('owned'); btn.textContent = '✓ ' + t('bought'); btn.disabled = true; }
      else { card.classList.remove('owned'); btn.textContent = t('cores_cost', { n: mu.cost }); btn.disabled = s.cores < mu.cost; }
    }
  }
  function updateSingularity() {
    var s = G.state;
    var gain = G.coresGain();
    var btn = $('singBtn'); btn.textContent = t('singularity_btn');
    if (!G.singUnlocked()) {
      $('singGain').textContent = t('singularity_locked', { n: C.SINGULARITY.UNLOCK_RP });
      btn.disabled = true;
    } else {
      $('singGain').textContent = G.canSingularity() ? t('singularity_gain', { n: gain }) : t('singularity_locked', { n: C.SINGULARITY.UNLOCK_RP });
      btn.disabled = !G.canSingularity();
    }
    $('coresHave').textContent = t('cores_have', { n: s.cores });
    $('coresBonus').textContent = t('cores_bonus', { p: Math.round(s.cores * C.SINGULARITY.CORE_BONUS * 100) });
    updateMeta();
  }

  // ---------- cosmetics ----------
  var ORB_PREVIEW = {
    orb_default: 'radial-gradient(circle at 50% 35%, #b79bff, #5b27c4)',
    orb_cyan: 'radial-gradient(circle at 50% 35%, #a7f0ff, #0e7fa0)',
    orb_gold: 'radial-gradient(circle at 50% 35%, #fff0b8, #b6820c)',
    orb_crimson: 'radial-gradient(circle at 50% 35%, #ffb3c2, #a11733)'
  };
  var THEME_PREVIEW = {
    theme_default: 'linear-gradient(135deg, #8b5cf6, #22d3ee)',
    theme_void: 'linear-gradient(135deg, #1a1830, #050509)',
    theme_aurora: 'linear-gradient(135deg, #34d399, #22d3ee)'
  };
  function lockReq(u) {
    if (u.prestiges) return t('cos_locked_prestiges', { n: u.prestiges });
    if (u.singularities) return t('cos_locked_singularities', { n: u.singularities });
    if (u.ach) return t('cos_locked_ach', { n: u.ach });
    return '';
  }
  function buildCosmetics() {
    [['cosOrbList', C.COSMETICS.orbs, ORB_PREVIEW, 'orb'], ['cosThemeList', C.COSMETICS.themes, THEME_PREVIEW, 'theme']].forEach(function (row) {
      var list = $(row[0]); if (!list) return; list.innerHTML = '';
      row[1].forEach(function (it) {
        var sw = el('div', 'cos-swatch'); sw.dataset.cid = it.id; sw.dataset.kind = row[3];
        sw.style.background = row[2][it.id] || '#333';
        sw.title = t(it.id);
        sw.innerHTML = '<div class="lockicon hidden">' + ic('ic_lock') + '</div>';
        sw.addEventListener('click', function () {
          var ok = row[3] === 'orb' ? G.setOrb(it.id) : G.setTheme(it.id);
          if (ok) { window.GAME_AUDIO.buy(); applyCosmetics(); }
        });
        list.appendChild(sw);
      });
    });
  }
  function updateCosmetics() {
    var s = G.state;
    [['cosOrbList', C.COSMETICS.orbs, s.orb], ['cosThemeList', C.COSMETICS.themes, s.theme]].forEach(function (row) {
      var list = $(row[0]); if (!list) return;
      for (var i = 0; i < list.children.length; i++) {
        var sw = list.children[i], it = row[1][i];
        var unlocked = G.cosmeticUnlocked(it);
        sw.classList.toggle('locked', !unlocked);
        sw.classList.toggle('sel', row[2] === it.id);
        var li = sw.querySelector('.lockicon');
        if (li) { li.classList.toggle('hidden', unlocked); if (!unlocked) li.innerHTML = ic('ic_lock'); }
        sw.title = unlocked ? t(it.id) : (t(it.id) + ' — ' + lockReq(it.unlock || {}));
      }
    });
  }
  function applyCosmetics() {
    var s = G.state, de = document.documentElement;
    if (de.getAttribute('data-orb') !== s.orb) de.setAttribute('data-orb', s.orb);
    if (de.getAttribute('data-theme') !== s.theme) de.setAttribute('data-theme', s.theme);
  }

  // ---------- news ticker ----------
  var tickerIdx = -1, tickerTimer = null;
  function currentNews() {
    var lang = window.GAME_I18N.getLang();
    var arr = (window.GAME_I18N.DICTS[lang] && window.GAME_I18N.DICTS[lang].news) || window.GAME_I18N.DICTS.en.news || [];
    var stage = parseInt(document.documentElement.getAttribute('data-stage') || '0', 10) || 0;
    return arr[Math.min(stage, arr.length - 1)] || arr[0] || [''];
  }
  function rotateTicker() {
    var pool = currentNews(); if (!pool.length) return;
    tickerIdx = (tickerIdx + 1) % pool.length;
    var el2 = $('tickerText');
    if (el2) { el2.textContent = pool[tickerIdx]; el2.style.animation = 'none'; void el2.offsetWidth; el2.style.animation = ''; }
  }
  function startTicker() { rotateTicker(); if (tickerTimer) clearInterval(tickerTimer); tickerTimer = setInterval(rotateTicker, 9000); }

  // ---------- achievements ----------
  function buildAchievements() {
    var list = $('achList');
    list.innerHTML = '';
    C.ACHIEVEMENTS.forEach(function (a) {
      var card = el('div', 'ach locked');
      card.dataset.aid = a.id;
      var perk = '';
      if (a.perk) {
        var pt = a.perk.type === 'global' ? t('perk_global', { p: Math.round((a.perk.value - 1) * 100) }) : t('perk_tap', { n: a.perk.value });
        perk = '<div class="aperk">' + t('perk_label') + ' · ' + pt + '</div>';
      }
      card.innerHTML =
        '<div class="aicon">' + ic('nav_achievements') + '</div>' +
        '<div><div class="aname">' + t(a.id) + '</div><div class="adesc">' + t(a.id + '_d') + '</div>' + perk + '</div>' +
        '<div class="check hidden">' + ic('ic_check') + '</div>';
      list.appendChild(card);
    });
  }
  function updateAchievements() {
    var s = G.state;
    var nodes = $('achList').children;
    var unlocked = 0;
    for (var i = 0; i < nodes.length; i++) {
      var a = C.ACHIEVEMENTS[i];
      var has = !!s.achievements[a.id];
      if (has) unlocked++;
      nodes[i].classList.toggle('locked', !has);
      nodes[i].querySelector('.check').classList.toggle('hidden', !has);
    }
    $('achProgress').textContent = t('ach_progress', { n: unlocked, m: C.ACHIEVEMENTS.length });
  }

  // ---------- stats ----------
  function updateStats() {
    var s = G.state;
    var totalGens = 0;
    C.GENERATORS.forEach(function (g) { totalGens += s.gens[g.id]; });
    var rows = [
      [t('stat_total_cash'), fmt(s.totalEarnedAllTime)],
      [t('stat_this_run'), fmt(s.totalEarnedThisRun)],
      [t('stat_cps'), fmt(G.cps())],
      [t('stat_taps'), s.taps],
      [t('stat_generators'), totalGens],
      [t('stat_prestiges'), s.prestiges],
      [t('stat_rp'), s.rp],
      [t('stat_total_rp'), s.totalRP],
      [t('stat_incidents'), s.incidentsTotal],
      [t('stat_playtime'), FMT.fmtTime(s.playtime)]
    ];
    var html = '';
    rows.forEach(function (r) { html += '<div class="statItem"><span>' + r[0] + '</span><span>' + r[1] + '</span></div>'; });
    $('statList').innerHTML = html;
  }

  // ---------- research / prestige ----------
  function updateResearch() {
    var s = G.state;
    var gain = G.prestigeGain();
    $('prestigeGain').textContent = t('prestige_gain', { n: gain });
    var btn = $('prestigeBtn');
    btn.textContent = t('prestige_button');
    btn.disabled = !G.canPrestige();
    if (!G.canPrestige()) $('prestigeGain').textContent = t('prestige_locked');
    $('rpHave').textContent = t('rp_have', { n: s.rp });
    $('currentBonus').textContent = t('current_bonus', { p: Math.round(s.rp * C.PRESTIGE.BONUS * 100) });
  }

  // ---------- alignment (multi-vector) ----------
  function vecColor(v) { return v > C.RISK.WARN_AT ? 'linear-gradient(90deg, var(--warn), var(--bad))' : 'linear-gradient(90deg, var(--good), var(--warn))'; }
  function updateAlignment() {
    var s = G.state;
    // vector bars
    var html = '';
    C.RISK.VECTORS.forEach(function (vid) {
      var val = s.vec[vid], net = G.vectorNet(vid);
      var arrow = net > 0.001 ? '▲' : (net < -0.001 ? '▼' : '–');
      html += '<div class="vrow">' +
        '<div class="vhead"><span class="vname">' + t('vec_' + vid) + '</span><span class="vpct">' + Math.floor(val) + '%</span></div>' +
        '<div class="bar"><div class="vfill" style="width:' + val + '%;background:' + vecColor(val) + '"></div></div>' +
        '<div class="vmeta muted small">' + t('vec_' + vid + '_d') + ' · <span class="' + (net > 0 ? 'vup' : 'vdn') + '">' + arrow + ' ' + Math.abs(net).toFixed(2) + '/s</span></div>' +
        '</div>';
    });
    $('vectorBars').innerHTML = html;
    $('alignOwned').textContent = s.align;
    $('alignSuppressTxt').textContent = t('align_suppress', { v: G.alignSuppress().toFixed(2) });
    var ac = G.alignCost();
    var btn = $('buyAlignBtn');
    btn.textContent = t('buy_alignment') + ' (' + fmt(ac) + ')';
    btn.disabled = s.cash < ac;
    // reactive audit (cooldown, not an instant crisis-clear)
    var ab = $('auditBtn');
    if (G.auditReady()) { ab.disabled = G.auditCost() <= 0 || s.cash < G.auditCost() || G.riskLevel() < 1; ab.textContent = t('audit_btn', { v: fmt(G.auditCost()) }); ab.classList.remove('cooldown'); }
    else { ab.disabled = true; ab.textContent = t('audit_cd', { t: FMT.fmtTime(G.auditCooldownLeft()) }); ab.classList.add('cooldown'); }
    // crisis penalty box (no instant contain — invest in alignment to prevent)
    var ib = $('incidentBox');
    if (G.incidentActive()) {
      ib.classList.remove('hidden');
      var remain = Math.max(0, (s.incidentEndsAt - Date.now()) / 1000);
      ib.innerHTML =
        '<div class="ititle">' + t('incident_active', { p: C.RISK.INCIDENT_PENALTY }) + '</div>' +
        '<div class="idesc">' + t('crisis_penalty_desc', { t: FMT.fmtTime(remain) }) + '</div>';
    } else { ib.classList.add('hidden'); }
    // mini-stats
    function mini(label, val) { return '<div class="minicard"><div class="mlabel">' + label + '</div><div class="mval">' + val + '</div></div>'; }
    var hv = G.highestVector();
    $('alignMini').innerHTML =
      mini(t('mini_cps'), fmt(G.cps())) +
      mini(t('mini_output'), '×' + fmt(G.globalMult())) +
      mini(t('mini_toprisk'), t('vec_' + hv.id) + ' ' + Math.floor(hv.val) + '%') +
      mini(t('mini_suppress'), G.alignSuppress().toFixed(2));
    // mini bar on company tab = highest vector
    var pct = hv.val;
    var mfill = $('riskMiniFill');
    if (mfill) { mfill.style.width = pct + '%'; mfill.style.background = vecColor(pct); }
    var mpct = $('riskMiniPct');
    if (mpct) mpct.textContent = Math.floor(pct) + '%';
  }

  // ---------- top bar / boost ----------
  function updateTop() {
    var s = G.state;
    setOdometer($('cashVal'), s.cash);
    $('cpsVal').textContent = t('per_sec', { v: fmt(G.cps()) });
    $('tapValue').textContent = '+' + fmt(G.tapValue());

    // atmosphere intensity rises with output toward AGI
    var inten = Math.max(0, Math.min(1, (Math.log10(G.cps() + 10) - 1) / 9));
    document.documentElement.style.setProperty('--intensity', inten.toFixed(3));
    if (window.GAME_MUSIC) window.GAME_MUSIC.setIntensity(inten);
    // discrete evolving backdrop stage (highest hardware tier + singularity)
    var hi = -1;
    for (var gx = 0; gx < C.GENERATORS.length; gx++) if (s.gens[C.GENERATORS[gx].id] > 0) hi = gx;
    var stage = Math.min(4, Math.floor((hi + 1) / 2.6));
    if (s.singularities > 0) stage = 5;
    if (document.documentElement.getAttribute('data-stage') !== String(stage)) document.documentElement.setAttribute('data-stage', String(stage));

    // overclock heat -> combo bar + button glow
    var heat = s.comboHeat || 0;
    $('tapBtn').style.setProperty('--heat', heat.toFixed(3));
    var cw = $('comboWrap');
    if (heat > 0.02) {
      cw.classList.add('on');
      $('comboName').textContent = t('combo_label');
      $('comboMult').textContent = '×' + (1 + G.comboBonus()).toFixed(1);
      $('comboFill').style.width = (heat * 100) + '%';
    } else { cw.classList.remove('on'); }

    // breakthrough button
    var btn = $('breakthroughBtn');
    btn.classList.remove('hidden');
    if (G.breakthroughActive()) {
      btn.disabled = true;
      btn.textContent = t('breakthrough_active', { t: FMT.fmtTime((s.breakthroughEndsAt - Date.now()) / 1000) });
      btn.classList.add('bt-active');
    } else if (G.breakthroughReady()) {
      btn.disabled = false;
      btn.textContent = t('breakthrough_btn') + ' · ' + t('breakthrough_ready');
      btn.classList.remove('bt-active');
    } else {
      btn.disabled = true;
      btn.textContent = t('breakthrough_btn') + ' · ' + FMT.fmtTime(G.breakthroughCooldownLeft());
      btn.classList.remove('bt-active');
    }

    // buff badge (priority: breakthrough > frenzy > clickFrenzy > ad boost)
    var bb = $('boostBadge');
    if (G.breakthroughActive()) {
      bb.classList.remove('hidden');
      bb.textContent = t('buff_breakthrough', { m: s.breakthroughMult, t: FMT.fmtTime((s.breakthroughEndsAt - Date.now()) / 1000) });
    } else if (G.frenzyActive()) {
      bb.classList.remove('hidden');
      bb.textContent = t('buff_frenzy', { m: s.frenzyMult, t: FMT.fmtTime((s.frenzyEndsAt - Date.now()) / 1000) });
    } else if (G.clickFrenzyActive()) {
      bb.classList.remove('hidden');
      bb.textContent = t('buff_click', { m: s.clickFrenzyMult, t: FMT.fmtTime((s.clickFrenzyEndsAt - Date.now()) / 1000) });
    } else if (G.boostActive()) {
      bb.classList.remove('hidden');
      bb.textContent = t('boost_active', { t: FMT.fmtTime((s.boostUntil - Date.now()) / 1000) });
    } else bb.classList.add('hidden');
    var eb = $('eventBadge');
    if (G.eventActive() && s.eventId) {
      eb.classList.remove('hidden');
      eb.classList.toggle('bad', s.eventId === 'shortage');
      eb.textContent = t('ev_active', { name: t('ev_' + s.eventId), t: FMT.fmtTime((s.eventEndsAt - Date.now()) / 1000) });
    } else eb.classList.add('hidden');
  }

  // ---------- World: news cards, crises, market ----------
  function cardTag(kind) { return kind === 'crisis' ? t('tag_crisis') : kind === 'opportunity' ? t('tag_opportunity') : t('tag_decision'); }
  function cardChoiceLabel(cardId, choiceId) { return t(cardId + '_' + choiceId); }
  function renderCardHTML(card) {
    var tpl = G.cardTemplate(card); if (!tpl) return '';
    var remain = Math.max(0, (card.expiresAt - Date.now()) / 1000);
    var btns = tpl.choices.map(function (ch) {
      return '<button class="cardchoice" data-uid="' + card.uid + '" data-ch="' + ch.id + '">' + cardChoiceLabel(card.id, ch.id) + '</button>';
    }).join('');
    return '<div class="newscard ' + card.kind + '">' +
      '<div class="nc-tag">' + cardTag(card.kind) + '</div>' +
      '<div class="nc-title">' + t(card.id + '_t') + '</div>' +
      '<div class="nc-desc">' + t(card.id + '_d') + '</div>' +
      '<div class="nc-timer muted small">' + t('card_expires', { t: FMT.fmtTime(remain) }) + '</div>' +
      '<div class="nc-choices">' + btns + '</div></div>';
  }
  function wireCardButtons(container) {
    var bs = container.querySelectorAll('.cardchoice');
    for (var i = 0; i < bs.length; i++) {
      (function (b) {
        b.addEventListener('click', function () {
          if (G.resolveCard(parseInt(b.dataset.uid, 10), b.dataset.ch)) {
            window.GAME_AUDIO.buy(); window.GAME_FX.flash('rgba(34,211,238,0.2)'); hideModal(); updateWorld();
          }
        });
      })(bs[i]);
    }
  }
  function showCrisisModal() {
    var crisis = null; for (var i = 0; i < G.state.cards.length; i++) if (G.state.cards[i].kind === 'crisis') crisis = G.state.cards[i];
    if (!crisis) return;
    showModal('<div class="crisis-modal">' + renderCardHTML(crisis) + '</div>');
    wireCardButtons($('modalRoot'));
  }
  function sparkline(hist) {
    if (!hist || hist.length < 2) return '';
    var min = Math.min.apply(null, hist), max = Math.max.apply(null, hist), rng = (max - min) || 1;
    var n = hist.length, pts = hist.map(function (v, i) { return (i / (n - 1) * 60).toFixed(1) + ',' + (20 - (v - min) / rng * 18).toFixed(1); }).join(' ');
    var up = hist[n - 1] >= hist[0];
    return '<svg class="spark" viewBox="0 0 60 20" preserveAspectRatio="none"><polyline points="' + pts + '" fill="none" stroke="' + (up ? 'var(--green)' : 'var(--rose)') + '" stroke-width="1.5"/></svg>';
  }
  function buildMarket() {
    var list = $('marketList'); if (!list) return; list.innerHTML = '';
    C.MARKET.assets.forEach(function (a) {
      var row = el('div', 'mkrow'); row.dataset.aid = a.id;
      row.innerHTML =
        '<div class="mk-info"><div class="mk-name">' + t('mk_' + a.id) + ' <span class="mk-sym">' + a.id + '</span></div>' +
        '<div class="mk-hold muted small"></div></div>' +
        '<div class="mk-spark"></div>' +
        '<div class="mk-price"></div>' +
        '<div class="mk-act"><button class="mk-buy" data-aid="' + a.id + '">' + t('market_buy') + '</button>' +
        '<button class="mk-sell" data-aid="' + a.id + '">' + t('market_sell') + '</button></div>';
      list.appendChild(row);
      row.querySelector('.mk-buy').addEventListener('click', function () { if (G.marketBuy(a.id, G.state.cash * 0.1)) { window.GAME_AUDIO.buy(); updateWorld(); } });
      row.querySelector('.mk-sell').addEventListener('click', function () { if (G.marketSell(a.id, 1)) { window.GAME_AUDIO.buy(); updateWorld(); } });
    });
  }
  function updateWorld() {
    var unlocked = G.worldUnlocked();
    $('worldLocked').classList.toggle('hidden', unlocked);
    ['worldNewsTitle', 'cardList', 'worldMarketTitle', 'marketIntro', 'marketList', 'newsFlavorTitle', 'newsFlavor'].forEach(function (id) { var e = $(id); if (e) e.classList.toggle('hidden', !unlocked); });
    if (!unlocked) { $('worldLocked').innerHTML = '<div class="es-icon">' + ic('ic_world') + '</div>' + t('world_locked'); return; }
    // active cards (skip crises here — they appear as a modal; but still list them)
    var cl = $('cardList'), html = '';
    G.state.cards.forEach(function (c) { html += renderCardHTML(c); });
    if (!html) html = '<div class="empty-state">' + t('ap_status_idle') + '</div>';
    cl.innerHTML = html; wireCardButtons(cl);
    // market
    G.ensureMarket(); var m = G.state.market;
    var rows = $('marketList').children;
    for (var i = 0; i < rows.length; i++) {
      var aid = rows[i].dataset.aid;
      rows[i].querySelector('.mk-price').textContent = fmt(m.price[aid]);
      rows[i].querySelector('.mk-spark').innerHTML = sparkline(m.hist[aid]);
      var hold = m.hold[aid];
      rows[i].querySelector('.mk-hold').textContent = hold > 0.0001 ? t('market_hold', { n: hold.toFixed(2), v: fmt(hold * m.price[aid]) }) : t('market_none');
      rows[i].querySelector('.mk-sell').disabled = hold <= 0.0001;
      rows[i].querySelector('.mk-buy').disabled = G.state.cash < 1;
    }
    // flavor headlines (stage-based)
    var pool = currentNews();
    $('newsFlavor').innerHTML = pool.map(function (h) { return '<div class="flavor-line">• ' + h + '</div>'; }).join('');
  }

  // ---------- next-goal nudge ----------
  function computeNudge() {
    var s = G.state;
    if (G.incidentActive()) return { key: 'nudge_incident', tone: 'urgent', icon: 'ic_risk' };
    if (G.riskLevel() >= C.RISK.WARN_AT) return { key: 'nudge_risk', tone: 'urgent', icon: 'ic_risk' };
    if (G.canSingularity && G.canSingularity()) return { key: 'nudge_singularity', vars: { n: G.coresGain() }, tone: 'go', icon: 'ic_core' };
    var pg = G.prestigeGain();
    if (pg >= Math.max(5, Math.floor(s.rp * 0.25))) return { key: 'nudge_prestige', vars: { n: pg }, tone: 'go', icon: 'ic_rp' };
    var totalOwned = 0; C.GENERATORS.forEach(function (g) { totalOwned += s.gens[g.id]; });
    if (totalOwned === 0) {
      if (s.cash < C.GENERATORS[0].baseCost) return { key: 'nudge_tap', icon: 'ic_brain' };
      return { key: 'nudge_buyfirst', vars: { name: t('g_' + C.GENERATORS[0].id) }, icon: 'gen_' + C.GENERATORS[0].id };
    }
    for (var i = 0; i < C.UPGRADES.length; i++) {
      var u = C.UPGRADES[i];
      if (!s.upgrades[u.id] && (!u.unlock || s.gens[u.unlock.gen] >= u.unlock.count) && s.cash >= u.cost)
        return { key: 'nudge_upgrade', vars: { name: t(u.id) }, icon: 'ic_upgrade' };
    }
    for (var g2 = 0; g2 < C.GENERATORS.length; g2++) {
      var gid = C.GENERATORS[g2].id, owned = s.gens[gid];
      if (owned > 0) { var nm = G.nextMilestone(owned); if (nm && nm - owned <= 5) return { key: 'nudge_milestone', vars: { n: nm - owned, name: t('g_' + gid) }, icon: 'gen_' + gid }; }
    }
    for (var h = C.GENERATORS.length - 1; h >= 0; h--) {
      var hg = C.GENERATORS[h];
      if (s.gens[hg.id] === 0 && s.cash >= G.genCostCumulative(hg.id, 1)) return { key: 'nudge_buygen', vars: { name: t('g_' + hg.id) }, icon: 'gen_' + hg.id };
    }
    for (var n2 = 0; n2 < C.GENERATORS.length; n2++) {
      var ng = C.GENERATORS[n2];
      if (s.gens[ng.id] === 0) return { key: 'nudge_savegen', vars: { name: t('g_' + ng.id), v: fmt(G.genCostCumulative(ng.id, 1)) }, icon: 'gen_' + ng.id };
    }
    return null;
  }
  function updateNudge() {
    var n = computeNudge(), box = $('nudge');
    if (!n) { box.classList.add('hidden'); return; }
    box.classList.remove('hidden', 'urgent', 'go');
    if (n.tone) box.classList.add(n.tone);
    box.querySelector('.nicon').innerHTML = ic(n.icon);
    $('nudgeText').textContent = t(n.key, n.vars);
  }

  // ---------- main per-frame update ----------
  function update() {
    updateTop();
    if (currentTab === 'company') updateGenerators();
    else if (currentTab === 'upgrades') { updateAutopilot(); updateUpgrades(); updateManagers(); }
    else if (currentTab === 'research') { updateResearch(); updateArtifacts(); updateTech(); }
    else if (currentTab === 'singularity') updateSingularity();
    else if (currentTab === 'world') updateWorld();
    else if (currentTab === 'alignment') updateAlignment();
    else if (currentTab === 'stats') updateStats();
    else if (currentTab === 'achievements') updateAchievements();
    // risk mini always (company tab) + settings seg states
    if (currentTab === 'company') { updateAlignment(); updateNudge(); }
    // reveal Singularity nav once unlocked
    var nsb = $('navSingBtn');
    if (nsb) nsb.classList.toggle('hidden', !G.singUnlocked());
    // World: nav reveal + Trust HUD + one-time unlock hint
    var wb = $('navWorldBtn'), wu = G.worldUnlocked();
    if (wb) wb.classList.toggle('hidden', !wu);
    var th = $('trustHud');
    if (th) { th.classList.toggle('hidden', !wu); if (wu) $('trustVal').textContent = Math.round(G.state.trust); }
    if (wu && !G.state.seen.world) { G.state.seen.world = true; toast(t('hint_world'), 'gold'); G.save(); }
    applyCosmetics();
    if (currentTab === 'settings') updateCosmetics();
    updateSettingsState();
  }

  function updateSettingsState() {
    var s = G.state;
    var lang = window.GAME_I18N.getLang();
    var lsg = $('langSeg').children;
    lsg[0].classList.toggle('on', lang === 'en');
    lsg[1].classList.toggle('on', lang === 'ru');
    var ssg = $('soundSeg').children;
    ssg[0].classList.toggle('on', s.sound);
    ssg[1].classList.toggle('on', !s.sound);
    var msg = $('musicSeg').children;
    msg[0].classList.toggle('on', s.music);
    msg[1].classList.toggle('on', !s.music);
  }

  // ---------- tabs ----------
  function switchTab(tab) {
    currentTab = tab;
    var tabs = document.querySelectorAll('.tab');
    for (var i = 0; i < tabs.length; i++) tabs[i].classList.toggle('active', tabs[i].dataset.tab === tab);
    var navs = $('tabbar').children;
    for (var j = 0; j < navs.length; j++) navs[j].classList.toggle('active', navs[j].dataset.tab === tab);
    var showBuyMode = (tab === 'company');
    $('buyModeBar').classList.toggle('hidden', !showBuyMode);
    update();
  }

  function updateBuyModeBar() {
    var btns = $('buyModeBar').children;
    for (var i = 0; i < btns.length; i++) {
      var m = btns[i].dataset.mode;
      var val = (m === 'max') ? 'max' : parseInt(m, 10);
      btns[i].classList.toggle('on', G.state.buyMode === val);
    }
  }

  // ---------- modal ----------
  function showModal(html) {
    var root = $('modalRoot');
    root.innerHTML = '<div class="modal">' + html + '</div>';
    root.classList.remove('hidden');
  }
  function hideModal() { $('modalRoot').classList.add('hidden'); $('modalRoot').innerHTML = ''; }

  function showOffline(off) {
    showModal(
      '<h3>' + t('offline_title') + '</h3>' +
      '<p>' + t('offline_away', { t: FMT.fmtTime(off.cappedSec) }) + '</p>' +
      '<div class="big">' + t('offline_earned', { v: fmt(off.earned) }) + '</div>' +
      '<div class="row">' +
      '<button class="primary" id="offCollect">' + t('offline_collect') + '</button>' +
      '<button class="reward" id="offDouble">' + t('offline_double') + '</button>' +
      '</div>'
    );
    $('offCollect').onclick = function () { G.applyOffline(off.earned); hideModal(); };
    $('offDouble').onclick = function () {
      window.GAME_ADS.showRewarded({
        onReward: function () { G.applyOffline(off.earned * 2); hideModal(); },
        onUnavailable: function () { G.applyOffline(off.earned); hideModal(); toast(t('ad_unavailable'), 'bad'); }
      });
    };
  }

  // ---------- insight flash collectible ----------
  function removeInsight() { var e = $('insightFlash'); if (e && e.parentNode) e.parentNode.removeChild(e); }
  function spawnInsight(lifetime) {
    removeInsight();
    var e = el('div'); e.id = 'insightFlash'; e.innerHTML = ic('ic_insight');
    e.setAttribute('role', 'button'); e.setAttribute('aria-label', t('insight_appear'));
    document.body.appendChild(e);
    var w = window.innerWidth, h = window.innerHeight;
    var x0 = 24 + Math.random() * Math.max(40, w - 130);
    var y0 = 100 + Math.random() * Math.max(40, h - 280);
    e.style.left = x0 + 'px'; e.style.top = y0 + 'px';
    e.style.transition = 'left ' + lifetime + 's linear, top ' + lifetime + 's linear, transform 0.12s';
    requestAnimationFrame(function () {
      var x1 = Math.max(24, Math.min(w - 90, x0 + (Math.random() * 220 - 110)));
      var y1 = Math.max(90, Math.min(h - 170, y0 + (Math.random() * 180 - 90)));
      e.style.left = x1 + 'px'; e.style.top = y1 + 'px';
    });
    function claim(ev) {
      ev.preventDefault(); ev.stopPropagation();
      var rect = e.getBoundingClientRect();
      var res = G.claimInsight();
      removeInsight();
      if (res) {
        var ix = rect.left + rect.width / 2, iy = rect.top + rect.height / 2;
        window.GAME_AUDIO.insight();
        window.GAME_FX.insightBurst(ix, iy);
        window.GAME_FX.flash('rgba(251,191,36,0.38)');
        window.GAME_FX.shockwave(ix, iy, 'rgba(251,191,36,0.85)', 560);
        toast(t('insight_' + res.reward, res.vars), 'gold');
      }
    }
    e.addEventListener('click', claim);
    e.addEventListener('touchstart', claim, { passive: false });
  }

  // ---------- onboarding tour ----------
  function showOnboarding() {
    var steps = [
      { icon: ic('ic_brain'), title: 'ob_1_title', body: 'ob_1_body' },
      { icon: ic('gen_laptop'), title: 'ob_2_title', body: 'ob_2_body' },
      { icon: ic('nav_alignment'), title: 'ob_3_title', body: 'ob_3_body' }
    ];
    var i = 0;
    function finish() { G.setOnboarded(true); hideModal(); }
    function render() {
      var s = steps[i];
      var dots = '';
      for (var k = 0; k < steps.length; k++) dots += '<span class="dot' + (k === i ? ' on' : '') + '"></span>';
      var lastBtn = (i === steps.length - 1) ? t('ob_done') : t('ob_next');
      showModal(
        '<div class="ob">' +
        '<div class="ob-icon">' + s.icon + '</div>' +
        '<h3>' + t(s.title) + '</h3>' +
        '<p>' + t(s.body) + '</p>' +
        '<div class="ob-dots">' + dots + '</div>' +
        '<div class="row">' +
        '<button class="secondary" id="obSkip">' + t('ob_skip') + '</button>' +
        '<button class="primary" id="obNext">' + lastBtn + '</button>' +
        '</div></div>'
      );
      $('obSkip').onclick = finish;
      $('obNext').onclick = function () { if (i < steps.length - 1) { i++; render(); } else finish(); };
    }
    render();
  }

  // ---------- events ----------
  function bind() {
    // tap
    var tapBtn = $('tapBtn');
    function doTap(clientX, clientY) {
      var v = G.tap();
      window.GAME_AUDIO.tap();
      var cls = G.clickFrenzyActive() ? 'crit' : (G.state.comboHeat > 0.6 ? 'big' : '');
      floatText(clientX, clientY, '+' + fmt(v), cls);
      window.GAME_FX.tapBurst(clientX, clientY);
      window.GAME_FX.ripple(clientX, clientY, 130);
      tapBtn.classList.remove('squash'); void tapBtn.offsetWidth; tapBtn.classList.add('squash');
    }
    tapBtn.addEventListener('click', function (e) { doTap(e.clientX, e.clientY); });

    // tab nav
    var navs = $('tabbar').children;
    for (var i = 0; i < navs.length; i++) {
      (function (btn) { btn.addEventListener('click', function () { switchTab(btn.dataset.tab); }); })(navs[i]);
    }

    // buy mode
    var bms = $('buyModeBar').children;
    for (var k = 0; k < bms.length; k++) {
      (function (btn) {
        btn.addEventListener('click', function () {
          var m = btn.dataset.mode;
          G.setBuyMode(m === 'max' ? 'max' : parseInt(m, 10));
          updateBuyModeBar();
        });
      })(bms[k]);
    }

    // prestige
    $('prestigeBtn').addEventListener('click', function () {
      var gain = G.prestigeGain();
      showModal(
        '<h3>' + t('research_title') + '</h3>' +
        '<p>' + t('prestige_confirm', { n: gain }) + '</p>' +
        '<div class="row"><button class="secondary" id="pCancel">✕</button>' +
        '<button class="primary" id="pOk">' + t('prestige_button') + '</button></div>'
      );
      $('pCancel').onclick = hideModal;
      $('pOk').onclick = function () {
        hideModal();
        if (G.doPrestige()) {
          window.GAME_AUDIO.prestige();
          var f = t('flavor_' + Math.floor((G.state.prestiges) % 5));
          window.GAME_FX.ritual({ kind: 'prestige', title: t('ritual_model'), subtitle: f });
          // interstitial on prestige (graceful)
          window.GAME_ADS.showInterstitial({});
        }
      };
    });

    // autopilot controls
    var apOn = $('apOnSeg').children;
    apOn[0].addEventListener('click', function () { G.setAutopilotOn(true); window.GAME_AUDIO.buy(); updateAutopilot(); });
    apOn[1].addEventListener('click', function () { G.setAutopilotOn(false); updateAutopilot(); });
    $('apReserve').addEventListener('input', function () { G.setAutopilotReserve(parseInt(this.value, 10) / 100); updateAutopilot(); });
    var apMode = $('apModeSeg').children;
    apMode[0].addEventListener('click', function () { G.setAutopilotMode('roi'); window.GAME_AUDIO.buy(); updateAutopilot(); });
    apMode[1].addEventListener('click', function () { G.setAutopilotMode('milestone'); window.GAME_AUDIO.buy(); updateAutopilot(); });

    // singularity (second prestige)
    $('singBtn').addEventListener('click', function () {
      if (!G.canSingularity()) return;
      var gain = G.coresGain();
      showModal(
        '<h3>' + t('singularity_title') + '</h3>' +
        '<p>' + t('singularity_confirm', { n: gain }) + '</p>' +
        '<div class="row"><button class="secondary" id="sCancel">✕</button>' +
        '<button class="primary" id="sOk">' + t('singularity_btn') + '</button></div>'
      );
      $('sCancel').onclick = hideModal;
      $('sOk').onclick = function () {
        hideModal();
        if (G.doSingularity()) {
          window.GAME_FX.ritual({ kind: 'singularity', title: t('ritual_singularity'), subtitle: t('sing_flavor') });
          window.GAME_AUDIO.prestige();
          switchTab('company');
        }
      };
    });
    // (singularity flavor shown in the ritual cinematic subtitle)
    G.on('card', function (d) {
      if (d.kind === 'crisis') { window.GAME_AUDIO.incident(); window.GAME_FX.flash('rgba(251,92,120,0.25)'); showCrisisModal(); }
      else if (d.kind === 'escalate') { window.GAME_AUDIO.incident(); toast(t('incident_active', { p: C.RISK.INCIDENT_PENALTY }), 'bad'); }
    });

    // alignment buy + reactive audit
    $('buyAlignBtn').addEventListener('click', function () { if (G.buyAlignment()) window.GAME_AUDIO.buy(); });
    $('auditBtn').addEventListener('click', function () { if (G.doAudit()) { window.GAME_AUDIO.buy(); window.GAME_FX.flash('rgba(52,211,153,0.25)'); } });

    // breakthrough ability
    $('breakthroughBtn').addEventListener('click', function () {
      if (G.activateBreakthrough()) {
        window.GAME_AUDIO.prestige();
        var bx = window.innerWidth / 2, by = window.innerHeight * 0.42;
        window.GAME_FX.flash('rgba(34,211,238,0.4)');
        window.GAME_FX.shockwave(bx, by, 'rgba(34,211,238,0.9)', 720);
        window.GAME_FX.milestoneBurst(bx, by);
        window.GAME_FX.confetti(30);
      }
    });
    G.on('breakthrough', function (d) {
      toast(t(d.chained ? 'breakthrough_chain' : 'breakthrough_fire', { m: d.mult }), 'gold');
    });

    // insight flash (drifting collectible)
    G.on('insight', function (d) {
      if (d.kind === 'spawn') { spawnInsight(d.lifetime); window.GAME_AUDIO.achievement(); toast(t('insight_appear'), 'gold'); }
      else if (d.kind === 'despawn') { removeInsight(); toast(t('insight_gone')); }
    });

    // language
    var lsg = $('langSeg').children;
    for (var a = 0; a < lsg.length; a++) {
      (function (btn) {
        btn.addEventListener('click', function () { G.setLang(btn.dataset.lang); renderStatic(); update(); });
      })(lsg[a]);
    }
    // sound
    var ssg = $('soundSeg').children;
    for (var b = 0; b < ssg.length; b++) {
      (function (btn) {
        btn.addEventListener('click', function () {
          var on = btn.dataset.sound === 'on';
          G.setSound(on); window.GAME_AUDIO.setEnabled(on);
          if (on) window.GAME_AUDIO.buy();
        });
      })(ssg[b]);
    }
    // music
    var msg = $('musicSeg').children;
    for (var mb = 0; mb < msg.length; mb++) {
      (function (btn) {
        btn.addEventListener('click', function () {
          var on = btn.dataset.music === 'on';
          G.setMusic(on);
          if (window.GAME_MUSIC) { window.GAME_MUSIC.setEnabled(on); if (on) window.GAME_MUSIC.start(); }
        });
      })(msg[mb]);
    }
    // ad buttons
    $('adBoostBtn').addEventListener('click', function () {
      window.GAME_ADS.showRewarded({
        onReward: function () { G.applyBoost(); },
        onUnavailable: function () { toast(t('ad_unavailable'), 'bad'); }
      });
    });
    $('adCashBtn').addEventListener('click', function () {
      window.GAME_ADS.showRewarded({
        onReward: function () { G.addCashBurst(); },
        onUnavailable: function () { toast(t('ad_unavailable'), 'bad'); }
      });
    });
    // save / reset
    $('saveBtn').addEventListener('click', function () { G.save(); toast(t('saved_toast')); });
    $('resetBtn').addEventListener('click', function () {
      showModal('<div class="ob-icon" style="color:var(--rose)">' + ic('ic_risk') + '</div><p>' + t('reset_confirm') + '</p>' +
        '<div class="row"><button class="secondary" id="rCancel">✕</button>' +
        '<button class="primary danger" id="rOk">' + t('reset_progress') + '</button></div>');
      $('rCancel').onclick = hideModal;
      $('rOk').onclick = function () { G.reset(); hideModal(); renderStatic(); update(); toast(t('reset_done')); };
    });

    // game events
    G.on('achievement', function (d) {
      window.GAME_AUDIO.achievement();
      toast(t('ach_unlocked', { name: t(d.id) }), 'gold');
    });
    G.on('toast', function (d) { toast(t(d.key, d.vars), d.key === 'incident_resolved' ? '' : ''); });
    G.on('incident', function (d) { if (d.active) { window.GAME_AUDIO.incident(); toast(t('incident_active', { p: C.RISK.INCIDENT_PENALTY }), 'bad'); if (window.GAME_FX) window.GAME_FX.incident(); } });
    G.on('gameevent', function (d) {
      if (d.kind === 'end') return;
      var bad = (d.id === 'shortage' || d.id === 'leak');
      window.GAME_AUDIO.achievement();
      toast(t('ev_' + d.id) + ' — ' + t('ev_' + d.id + '_d'), bad ? 'bad' : 'gold');
    });
    G.on('milestone', function (d) {
      var major = d.milestone >= 25;
      if (major && window.GAME_AUDIO.milestone) window.GAME_AUDIO.milestone(); else window.GAME_AUDIO.achievement();
      var r = genRefs[d.id];
      var b = r && r.el ? r.el.getBoundingClientRect() : null;
      var x = b ? b.left + b.width / 2 : window.innerWidth / 2;
      var y = b ? b.top + b.height / 2 : window.innerHeight / 2;
      if (major) {
        // real celebration at 25/50/100/... (bigger at 100+)
        window.GAME_FX.celebrate(window.innerWidth / 2, window.innerHeight * 0.4, '×2  ' + d.milestone + '!', d.milestone >= 100);
        if (r && r.el) window.GAME_FX.cardFlash(r.el);
      } else {
        window.GAME_FX.milestoneBurst(x, y);
        window.GAME_FX.popText(x, y, '×2!', 'big');
        if (r && r.el) window.GAME_FX.cardFlash(r.el);
      }
    });
  }

  // ---------- init ----------
  function init(offline) {
    if (built) return;
    built = true;
    renderStatic();
    bind();
    window.GAME_AUDIO.setEnabled(G.state.sound);
    if (window.GAME_MUSIC) { window.GAME_MUSIC.setEnabled(G.state.music); if (G.state.music) window.GAME_MUSIC.start(); }
    applyCosmetics();
    startTicker();
    updateBuyModeBar();
    // deep-linkable tab via URL hash (e.g. #stats)
    var validTabs = { company: 1, upgrades: 1, research: 1, singularity: 1, alignment: 1, world: 1, stats: 1, achievements: 1, settings: 1 };
    var hash = (location.hash || '').replace('#', '');
    switchTab(validTabs[hash] ? hash : 'company');
    window.addEventListener('hashchange', function () {
      var h = (location.hash || '').replace('#', '');
      if (validTabs[h]) switchTab(h);
    });
    update();
    if (offline && offline.earned > 0) {
      showOffline(offline);
      if (!G.state.onboarded) G.setOnboarded(true); // returning player; skip tour
    } else if (!G.state.onboarded) {
      showOnboarding();
    }
  }

  window.GAME_UI = { init: init, update: update, toast: toast, renderStatic: renderStatic };
})();
