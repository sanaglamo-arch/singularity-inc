/* Singularity Inc. — central config: ALL tunable economy numbers live here.
   Exposed as window.GAME_CONFIG. No logic, just data. */
(function () {
  'use strict';

  // ---- Generators (hardware tiers) -------------------------------------
  // cost(n) = baseCost * growth^(owned).  out = baseOut per unit / sec.
  // Numbers mirror a proven AdCap-style curve, retuned for this theme.
  var GENERATORS = [
    { id: 'laptop',      icon: '💻', baseCost: 15,        growth: 1.070, baseOut: 0.10 },
    { id: 'gpuRig',      icon: '🎛️', baseCost: 110,       growth: 1.075, baseOut: 1.0 },
    { id: 'serverRack',  icon: '🗄️', baseCost: 1200,      growth: 1.080, baseOut: 8.0 },
    { id: 'gpuCluster',  icon: '⚡',      baseCost: 13000,     growth: 1.085, baseOut: 47 },
    { id: 'dataCenter',  icon: '🏢', baseCost: 140000,    growth: 1.090, baseOut: 260 },
    { id: 'superComp',   icon: '🖥️', baseCost: 1.6e6,     growth: 1.095, baseOut: 1400 },
    { id: 'neuroArray',  icon: '🧠', baseCost: 2.0e7,     growth: 1.100, baseOut: 7800 },
    { id: 'quantumNode', icon: '⚛️', baseCost: 3.3e8,     growth: 1.105, baseOut: 44000 },
    { id: 'orbital',     icon: '🛰️', baseCost: 5.1e9,     growth: 1.110, baseOut: 2.6e5 },
    { id: 'agiCore',     icon: '🌟', baseCost: 7.5e10,    growth: 1.120, baseOut: 1.6e6 },
    { id: 'dysonSwarm',  icon: '🛸', baseCost: 1.1e12,    growth: 1.125, baseOut: 9.5e6 },
    { id: 'matrioshka',  icon: '🌀', baseCost: 1.7e13,    growth: 1.130, baseOut: 5.8e7 }
  ];

  // Owned-count milestones that each multiply that generator's output x2.
  var MILESTONES = [10, 25, 50, 100, 150, 200, 300, 400, 500];

  // ---- Global upgrades (one-time multiplier purchases) ------------------
  // target 'all' = global mult; or a generator id = that generator only.
  // mult is multiplicative. unlock = {gen, count} requires owned>=count.
  var UPGRADES = [
    { id: 'u_tap1',   target: 'tap', mult: 2,  cost: 500,     unlock: null },
    { id: 'u_tap2',   target: 'tap', mult: 3,  cost: 50000,   unlock: { gen: 'laptop', count: 25 } },
    { id: 'u_lap1',   target: 'laptop',     mult: 2, cost: 1000,    unlock: { gen: 'laptop', count: 10 } },
    { id: 'u_rig1',   target: 'gpuRig',     mult: 2, cost: 9000,    unlock: { gen: 'gpuRig', count: 10 } },
    { id: 'u_rack1',  target: 'serverRack', mult: 2, cost: 90000,   unlock: { gen: 'serverRack', count: 10 } },
    { id: 'u_clus1',  target: 'gpuCluster', mult: 2, cost: 1.0e6,   unlock: { gen: 'gpuCluster', count: 10 } },
    { id: 'u_dc1',    target: 'dataCenter', mult: 2, cost: 1.1e7,   unlock: { gen: 'dataCenter', count: 10 } },
    { id: 'u_all1',   target: 'all', mult: 2,  cost: 2.5e6,   unlock: { gen: 'serverRack', count: 25 } },
    { id: 'u_all2',   target: 'all', mult: 2,  cost: 5.0e8,   unlock: { gen: 'dataCenter', count: 50 } },
    { id: 'u_super1', target: 'superComp', mult: 3, cost: 2.0e8, unlock: { gen: 'superComp', count: 10 } },
    { id: 'u_neuro1', target: 'neuroArray', mult: 3, cost: 2.5e9, unlock: { gen: 'neuroArray', count: 10 } },
    { id: 'u_all3',   target: 'all', mult: 3,  cost: 1.0e11,  unlock: { gen: 'quantumNode', count: 25 } },
    { id: 'u_quant1', target: 'quantumNode', mult: 3, cost: 4.0e10, unlock: { gen: 'quantumNode', count: 10 } },
    { id: 'u_orb1',   target: 'orbital', mult: 3, cost: 6.0e11, unlock: { gen: 'orbital', count: 10 } },
    { id: 'u_all4',   target: 'all', mult: 5,  cost: 5.0e13,  unlock: { gen: 'agiCore', count: 25 } },
    { id: 'u_agi1',   target: 'agiCore', mult: 3, cost: 9.0e12, unlock: { gen: 'agiCore', count: 10 } },
    { id: 'u_dyson1', target: 'dysonSwarm', mult: 3, cost: 1.4e14, unlock: { gen: 'dysonSwarm', count: 10 } },
    { id: 'u_matr1',  target: 'matrioshka', mult: 3, cost: 2.2e15, unlock: { gen: 'matrioshka', count: 10 } },
    { id: 'u_all5',   target: 'all', mult: 10, cost: 1.0e16, unlock: { gen: 'matrioshka', count: 25 } }
  ];

  // ---- Managers (automation: auto-buy a generator) ---------------------
  // Buying a manager auto-purchases that generator whenever affordable and
  // grants +50% to its output. cost in cash.
  var MANAGERS = GENERATORS.map(function (g, i) {
    return { id: 'm_' + g.id, gen: g.id, mult: 1.5, cost: g.baseCost * (i < 2 ? 40 : 60) };
  });

  // ---- Prestige --------------------------------------------------------
  // RP gained on prestige = floor( PRESTIGE_K * sqrt(totalEarnedThisRun / PRESTIGE_SCALE) )
  // Each RP grants +PRESTIGE_BONUS global multiplier (additive on a base of 1).
  // RP gained on release = floor( K * sqrt(totalEarnedThisRun / SCALE) ).
  // Each RP grants +BONUS to the PERMANENT global multiplier, FOREVER (baseline passive,
  // shown loudly at the release screen). The shop below is structural choice ON TOP.
  var PRESTIGE = {
    K: 1.4,               // RP gain rate (tuned so the first release lands ~35-45 min)
    SCALE: 1e6,
    BONUS: 0.05,          // +5% per RP to global mult, permanent
    MIN_TO_PRESTIGE: 1,   // engine floor: need >=1 RP to be allowed at all
    FIRST_RP: 5,          // the guided first-release CTA waits until the gain is this juicy
    // prestige (RP-bought) permanent upgrades. NO flat starting-cash items — starting
    // boosts are SCALING (% of your best run) or STRUCTURAL (keep generator levels).
    upgrades: [
      { id: 'p_mult1',   type: 'globalMult',  value: 2,    cost: 5 },
      { id: 'p_tap',     type: 'tapMult',     value: 10,   cost: 10 },
      { id: 'p_align',   type: 'alignBoost',  value: 2,    cost: 20 }, // alignment suppression x2
      { id: 'p_offline', type: 'offlineCap',  value: 4,    cost: 25 }, // +4h offline cap
      { id: 'p_seed',    type: 'startCashPct', value: 0.03, cost: 40 }, // start each run with 3% of best run
      { id: 'p_mult2',   type: 'globalMult',  value: 3,    cost: 50 },
      { id: 'p_keepgen', type: 'keepGens',    value: 0.06, cost: 120 }, // keep 6% of every generator level
      { id: 'p_offline2',type: 'offlineCap',  value: 12,   cost: 200 }, // +12h offline cap
      { id: 'p_mult3',   type: 'globalMult',  value: 5,    cost: 500 },
      { id: 'p_seed2',   type: 'startCashPct', value: 0.10, cost: 1500 }, // start with 10% of best run
      { id: 'p_mult4',   type: 'globalMult',  value: 10,   cost: 5000 }  // late-game global x10
    ]
  };

  // ---- Progressive-unlock schedule (player journey) --------------------
  // Sticky, monotonic gates on lifetime metrics. Stage 1 (Garage) shows ONLY the
  // tap->buy loop; depth reveals as the player grows. See BALANCE.md.
  var UNLOCKS = {
    BUYMODES_EARNED: 250,    // reveal x10/x100/Max bulk buying
    UPGRADES_EARNED: 500,    // reveal the Upgrades tab (first upgrade costs 500)
    INSIGHT_EARNED: 1500,    // the first delightful Insight-Flash surprise can appear
    BREAKTHROUGH_EARNED: 2.5e4, // reveal the Breakthrough ability
    MANAGERS_EARNED: 6e4,    // reveal Managers (manual buying is getting tedious)
    WORLD_RP: 70             // Stage 6 "Industry" (News/Trust/Market/Rivals) opens a bit
                             // after the first release; also opens at prestiges>=2
  };

  // ---- Risk / Alignment (signature mechanic) ---------------------------
  var RISK = {
    MAX: 100,
    // risk gained/sec = GAIN * capabilityFactor, capabilityFactor = log10(cps+10)/CAP_DIV
    GAIN: 0.55,
    CAP_DIV: 3,
    // each Alignment unit suppresses risk/sec by SUPPRESS (x alignBoost). R13: lowered
    // 0.20->0.12 so alignment is an ONGOING investment that scales with capability
    // (you keep funding it as you grow) instead of a trivial 5-and-done toggle.
    SUPPRESS: 0.12,
    alignBaseCost: 200,
    alignGrowth: 1.16,        // cost(n) = alignBaseCost * growth^owned (gentler so ongoing funding stays affordable)
    // incident
    INCIDENT_THRESHOLD: 100,
    INCIDENT_PENALTY: 0.20,   // output multiplied by this during incident
    INCIDENT_DURATION: 90,    // seconds (auto-resolves)
    INCIDENT_RESET_RISK: 35,  // a vector is reset to this after its crisis fires
    WARN_AT: 75,              // UI warns above this
    // ---- Multi-vector risk (replaces the single spam-defeatable bar) ----
    VECTORS: ['cap', 'data', 'reg', 'sec'],
    DATA_GENS: ['dataCenter', 'neuroArray', 'quantumNode', 'orbital', 'dysonSwarm', 'matrioshka'],
    CAP_GAIN: 0.5,            // capability: from output growth (log cps)
    DATA_GAIN: 0.0011,       // privacy/data: per data-heavy generator owned, /sec
    REG_BASE: 0.015,         // regulatory: small base drift /sec
    REG_DECAY: 0.05,         // regulatory decays toward 0 when below spikes
    REG_PRESTIGE_SPIKE: 11,  // hype: each model release bumps regulatory
    SEC_GAIN: 0.09,          // security: accrues over time /sec
    SUPPRESS_SHARE: 0.5,     // alignment suppression applied to data/reg/sec (cap gets full)
    // Reactive Audit: preemptive, costs cash, on cooldown — NOT an instant crisis-clear
    AUDIT_CUT: 35,           // reduces the highest vector by this
    AUDIT_FRAC: 0.18,        // cost = this fraction of current cash
    AUDIT_CD: 120,           // cooldown (seconds)
    // Crisis cadence — a global cooldown spaces crises out (anti-nag). Gentle early,
    // more pressure later: cooldown = clamp(BASE - prestiges*3 - singularities*10).
    CRISIS_CD_BASE: 165, CRISIS_CD_MIN: 95,
    // Escalation: an ignored crisis hits harder + longer than a handled one.
    ESCALATE_DUR_MULT: 1.6, ESCALATE_TRUST: 10
  };

  // ---- Tap -------------------------------------------------------------
  var TAP = { base: 2 };

  // ---- Offline ---------------------------------------------------------
  var OFFLINE = {
    BASE_CAP_HOURS: 8,
    AD_CAP_HOURS: 24,        // when watching rewarded ad
    RATE: 0.5                // offline earns 50% of current cps
  };

  // Anti-printer: every "X seconds of production" windfall (insight Eureka, event
  // grant, ad cash, news cashGift) is (a) computed from BASE cps — transient buffs
  // like Breakthrough/Frenzy/Hype no longer inflate it — and (b) capped at this
  // fraction of your best proven run, so windfalls can never self-compound into a
  // printer. (News cashGift uses its own tighter CARDS.CASHGIFT_CAP_FRAC.)
  var WINDFALL = { CAP_FRAC: 0.08 };

  // ---- Ad boosts -------------------------------------------------------
  var ADS = {
    BOOST_MULT: 2,           // 2x earnings
    BOOST_DURATION: 2 * 3600,// 2 hours
    CASH_BURST_SECONDS: 600, // instant cash = 10 min of production
    INTERSTITIAL_COOLDOWN: 120 // min seconds between interstitials
  };

  // ---- Achievements ----------------------------------------------------
  // check: function(state) -> bool. Defined in game.js via ids; metadata here.
  var ACHIEVEMENTS = [
    { id: 'a_firstTap',   cond: { type: 'taps', n: 1 } },
    { id: 'a_tap100',     cond: { type: 'taps', n: 100 } },
    { id: 'a_firstGen',   cond: { type: 'anyGen', n: 1 } },
    { id: 'a_lap50',      cond: { type: 'gen', gen: 'laptop', n: 50 } },
    { id: 'a_cash1m',     cond: { type: 'totalCash', n: 1e6 } },
    { id: 'a_cash1b',     cond: { type: 'totalCash', n: 1e9 } },
    { id: 'a_cash1t',     cond: { type: 'totalCash', n: 1e12 } },
    { id: 'a_prestige1',  cond: { type: 'modelGen', n: 1 } },
    { id: 'a_prestige5',  cond: { type: 'modelGen', n: 5 }, perk: { type: 'global', value: 1.05 } },
    { id: 'a_rp100',      cond: { type: 'marketShare', n: 25 } },
    { id: 'a_agi',        cond: { type: 'agi' }, perk: { type: 'global', value: 1.05 } },
    { id: 'a_align50',    cond: { type: 'align', n: 50 } },
    { id: 'a_incident',   cond: { type: 'incidents', n: 1 } },
    { id: 'a_safe',       cond: { type: 'researchers', n: 10 } },
    { id: 'a_event',      cond: { type: 'events', n: 1 } },
    { id: 'a_matrioshka', cond: { type: 'gen', gen: 'matrioshka', n: 1 } },
    { id: 'a_cash1qa',    cond: { type: 'totalCash', n: 1e15 } },
    { id: 'a_insight',    cond: { type: 'insights', n: 1 } },
    { id: 'a_breakthrough', cond: { type: 'breakthroughs', n: 1 } },
    { id: 'a_overclock',  cond: { type: 'maxheat', n: 1 } },
    { id: 'a_tech',       cond: { type: 'researchLevel', n: 1 } },
    { id: 'a_artifact',   cond: { type: 'datacenters', n: 1 } },
    { id: 'a_singularity', cond: { type: 'funding', n: 5 }, perk: { type: 'global', value: 1.10 } },
    { id: 'a_cores10',    cond: { type: 'modelGen', n: 8 }, perk: { type: 'tap', value: 2 } },
    { id: 'a_synergy',    cond: { type: 'marketLeader' }, perk: { type: 'global', value: 1.05 } },
    { id: 'a_techadept',  cond: { type: 'researchLevel', n: 6 } },
    { id: 'a_sing3',      cond: { type: 'modelGen', n: 10 }, perk: { type: 'global', value: 1.15 } },
    { id: 'a_cores50',    cond: { type: 'legacy', n: 1 } }
  ];

  // ---- Tap combo / Overclock heat -------------------------------------
  // Rapid tapping builds heat (0..1) that decays; tap value scales up to
  // x(1+maxBonus) at full heat. Rewards active bursts; makes TRAIN feel alive.
  var COMBO = { gainPerTap: 0.085, decayPerSec: 0.40, maxBonus: 4 };

  // ---- Insight Flash (Cookie-Clicker "golden cookie") ------------------
  // A glowing collectible drifts across the screen; tap in time for a buff.
  var INSIGHT = {
    MIN_GAP: 45, MAX_GAP: 95,   // seconds between spawns
    FIRST_DELAY: 40,            // earliest after run start
    LIFETIME: 13,              // seconds on screen before it escapes
    rewards: [
      { id: 'frenzy',      mult: 7,      duration: 30 }, // x7 global output 30s
      { id: 'clickFrenzy', tapMult: 100, duration: 15 }, // x100 tap value 15s
      { id: 'lucky',       cashSeconds: 900 }            // instant 15 min of income
    ]
  };

  // ---- Breakthrough ability (active, chainable) -----------------------
  var BREAKTHROUGH = {
    mult: 10, duration: 20, cooldown: 180,
    chainWindow: 8,            // re-fire within Ns of the last one ending => bonus
    chainMult: 15, chainDuration: 25
  };

  // ---- Generator classes (for tech/artifact category multipliers) ------
  var GEN_CLASS = {
    low:  ['laptop', 'gpuRig', 'serverRack'],
    mid:  ['gpuCluster', 'dataCenter', 'superComp', 'neuroArray'],
    high: ['quantumNode', 'orbital', 'agiCore', 'dysonSwarm', 'matrioshka']
  };

  // ---- Tech Tree (RP-gated; persists across model-release, resets on Singularity)
  // cat: tap | gen_low | gen_mid | gen_high | all | offline | risk
  // req: {} | {tech:id} | {gen:id, count:n}
  var TECH = [
    { id: 't_tap1',  cat: 'tap',      mult: 3,   cost: 12,   req: {} },
    { id: 't_low1',  cat: 'gen_low',  mult: 2,   cost: 18,   req: {} },
    { id: 't_off1',  cat: 'offline',  mult: 2,   cost: 25,   req: {} },
    { id: 't_risk1', cat: 'risk',     mult: 0.7, cost: 30,   req: {} },
    { id: 't_all1',  cat: 'all',      mult: 1.5, cost: 60,   req: { tech: 't_low1' } },
    { id: 't_mid1',  cat: 'gen_mid',  mult: 2,   cost: 90,   req: { gen: 'dataCenter', count: 25 } },
    { id: 't_tap2',  cat: 'tap',      mult: 5,   cost: 120,  req: { tech: 't_tap1' } },
    { id: 't_off2',  cat: 'offline',  mult: 3,   cost: 160,  req: { tech: 't_off1' } },
    { id: 't_all2',  cat: 'all',      mult: 2,   cost: 350,  req: { tech: 't_all1' } },
    { id: 't_high1', cat: 'gen_high', mult: 3,   cost: 600,  req: { gen: 'quantumNode', count: 10 } },
    { id: 't_risk2', cat: 'risk',     mult: 0.5, cost: 450,  req: { tech: 't_risk1' } },
    { id: 't_all3',  cat: 'all',      mult: 3,   cost: 2000, req: { tech: 't_all2' } }
  ];

  // ---- Prestige Artifacts (granted on model-release; equip up to SLOTS) -
  // tags drive synergy: each tag shared by >=2 equipped artifacts => +SYNERGY all
  var ARTIFACT_SLOTS = 3;
  var ARTIFACT_SYNERGY = 0.20; // +20% all per tag that has a matched pair equipped
  var ARTIFACTS = [
    { id: 'ar_chip',    tags: ['hw'],            effect: { type: 'allMult',     value: 1.10 } },
    { id: 'ar_cooler',  tags: ['hw', 'safety'],  effect: { type: 'riskMult',    value: 0.80 } },
    { id: 'ar_gpu',     tags: ['hw'],            effect: { type: 'genHighMult', value: 1.25 } },
    { id: 'ar_oracle',  tags: ['ai'],            effect: { type: 'tapMult',     value: 3 } },
    { id: 'ar_dataset', tags: ['ai'],            effect: { type: 'allMult',     value: 1.15 } },
    { id: 'ar_charter', tags: ['ai', 'safety'],  effect: { type: 'riskMult',    value: 0.70 } },
    { id: 'ar_vault',   tags: ['money'],         effect: { type: 'offlineMult', value: 2 } },
    { id: 'ar_fund',    tags: ['money'],         effect: { type: 'allMult',     value: 1.12 } },
    { id: 'ar_dice',    tags: ['gamble'],        effect: { type: 'gamble' } } // rolls 0.6..3.0 all, per run
  ];

  // ---- Second prestige: The Singularity (meta-currency: Singularity Cores) --
  var SINGULARITY = {
    UNLOCK_RP: 1200,           // unlocks at this lifetime RP ...
    UNLOCK_GEN: 'agiCore',     // ... or once an AGI Core exists
    SCALE: 100,                // cores = floor( sqrt(rp / SCALE) * coreGainMult )
    CORE_BONUS: 0.10,          // each Core = +10% global (passive)
    meta: [                    // permanent forever (Cores), never reset
      { id: 'sm_global1', type: 'globalMult',  value: 3,    cost: 1 },
      { id: 'sm_rp',      type: 'rpGain',      value: 2,    cost: 2 },
      { id: 'sm_tap',     type: 'tapMult',     value: 10,   cost: 2 },
      { id: 'sm_risk',    type: 'riskMult',    value: 0.5,  cost: 2 },
      { id: 'sm_offline', type: 'offlineCap',  value: 24,   cost: 3 },
      { id: 'sm_global2', type: 'globalMult',  value: 5,    cost: 5 },
      { id: 'sm_core',    type: 'coreGain',    value: 2,    cost: 6 },
      { id: 'sm_global3', type: 'globalMult',  value: 10,   cost: 12 }
    ]
  };

  // ---- Random timed events --------------------------------------------
  var EVENTS = {
    MIN_GAP: 150,        // min seconds between events
    MAX_GAP: 300,        // max seconds between events
    FIRST_DELAY: 75,     // no event before this much playtime (seconds)
    list: [
      { id: 'grant',      kind: 'instant', cashSeconds: 600 },  // +10 min of production
      { id: 'hype',       kind: 'timed',   duration: 60, outputMult: 2 },
      { id: 'shortage',   kind: 'timed',   duration: 45, outputMult: 0.5 },
      { id: 'leak',       kind: 'instant', riskAdd: 25 },
      { id: 'opensource', kind: 'instant', riskAdd: -30 }
    ]
  };

  // ---- Narrative campaign: Acts (monotonic, derived from lifetime progress) ----
  var ACTS = [
    { id: 'garage' },       // 0: start
    { id: 'startup' },      // 1: first generator owned
    { id: 'frontier' },     // 2: first model release (prestige)
    { id: 'race' },         // 3: rivals revealed (prestiges>=2 or totalRP>=120)
    { id: 'singularity' }   // 4: first Singularity reached (stays here; race+endings loop)
  ];

  // ---- Rival labs — the Race to AGI (revealed at Act 3) -----------------
  // GDD v3: rivals compete for MARKET SHARE and race to AGI on their own timelines.
  // share0 = starting %, shareRate = market share gained per second (slow creep —
  // you overtake by shipping generations), agiRate = AGI progress %/sec.
  var RIVALS = [
    { id: 'helion',  speed: 0.0150, share0: 17, shareRate: 0.00060, agiRate: 0.00050 },  // reckless front-runner
    { id: 'cerebra', speed: 0.0110, share0: 13, shareRate: 0.00045, agiRate: 0.00038 },  // steady
    { id: 'omninet', speed: 0.0085, share0: 9,  shareRate: 0.00032, agiRate: 0.00028 }   // cautious
  ];
  var RIVAL_SHARE_CAP = 45;   // a rival's market share tapers toward this ceiling
  // §5 light/optional acquisitions: buy out a rival to take its market share + remove it
  // from the race. cost = valuation × COST_FRAC × (1 + their AGI%/100); one-time per rival.
  var ACQUIRE = { UNLOCK_GEN: 5, COST_FRAC: 0.25, SHARE_TRANSFER: 0.6 };
  var RACE = {
    REVEAL_ACT: 3,
    PLAYER_TARGET_RP: 700,  // your AGI% = 100 * rp / TARGET (100% ~ when you can Ascend)
    HEAT: 0.6,              // as the leader nears AGI, everyone speeds up (climax tension)
    SLOW_OPENSOURCE: 14,    // open-sourcing knocks the leading rival back this much AGI%
    RECKLESS_RIVAL_BONUS: 0.4 // racing recklessly (low alignment) lets rivals gain faster too
  };

  // ---- Endings (resolve at the AGI climax; each = badge + small meta-perk) ----
  var ENDINGS = {
    PERK_PER: 0.04,         // +4% permanent global output per UNIQUE ending unlocked
    list: ['aligned', 'foom', 'nationalized', 'beaten', 'quiet'],
    // thresholds evaluated at ascension (avgVec = mean of risk vectors)
    QUIET_TRUST: 85, QUIET_AVGVEC: 18,
    NATIONALIZED_TRUST: 30, NATIONALIZED_AVGVEC: 65, NATIONALIZED_ESC: 3,
    FOOM_ALIGN: 3, FOOM_CAP: 55
  };

  // ---- Trust / Reputation ----------------------------------------------
  // Trust matters every second: output x scales 0.90 (trust 0) -> 1.00 (50) -> 1.10 (100).
  // High Trust unlocks premium contracts; low Trust adds regulatory pressure.
  var TRUST = { START: 60, MAX: 100, MIN: 0, OUTPUT_LO: 0.90, OUTPUT_HI: 1.10, LOW_REG_PRESSURE: 0.04 };

  // ---- Unified card system: crises + news decisions + opportunities -----
  // effect keys: cashFrac (-fraction of cash), trust (+/-), vec {id:delta},
  // penaltySec (output crisis penalty), allMult (one-time permanent x), cashGift (x seconds of cps)
  var CARDS = {
    CRISIS_EXPIRE: 28,        // seconds to decide before a crisis escalates
    NEWS_MIN: 100, NEWS_MAX: 180, // seconds between news/opportunity spawns
    NEWS_LIFE: 45,            // seconds an actionable news item stays
    // Anti-printer cap: any single cash windfall (cashGift) is capped at this
    // fraction of your best proven run, so World cards stay a bonus — never a
    // self-compounding money printer. cashGift values below are "seconds of cps".
    CASHGIFT_CAP_FRAC: 0.04,
    crises: [
      { id: 'c_cap', vector: 'cap', choices: [
        { id: 'pull',   effect: { cashFrac: -0.18 } },
        { id: 'spin',   effect: { trust: -10, vec: { reg: 18 } } },
        { id: 'ignore', effect: { penaltySec: 90 } } ] },
      { id: 'c_data', vector: 'data', choices: [
        { id: 'disclose', effect: { cashFrac: -0.15, trust: 6 } },
        { id: 'coverup',  effect: { trust: -16, vec: { reg: 22 } } },
        { id: 'ignore',   effect: { penaltySec: 90 } } ] },
      { id: 'c_reg', vector: 'reg', choices: [
        { id: 'comply', effect: { cashFrac: -0.12, trust: 8 } },
        { id: 'lobby',  effect: { cashFrac: -0.3, trust: -6 } },
        { id: 'ignore', effect: { penaltySec: 90, trust: -4 } } ] },
      { id: 'c_sec', vector: 'sec', choices: [
        { id: 'patch',  effect: { cashFrac: -0.14 } },
        { id: 'ransom', effect: { cashFrac: -0.28, trust: -5 } },
        { id: 'ignore', effect: { penaltySec: 90, vec: { sec: 20 } } } ] },
      { id: 'c_cap2', vector: 'cap', choices: [
        { id: 'sandbox', effect: { cashFrac: -0.16 } },
        { id: 'ship',    effect: { trust: -12, vec: { reg: 16 } } },
        { id: 'ignore',  effect: { penaltySec: 90 } } ] },
      { id: 'c_reg2', vector: 'reg', choices: [
        { id: 'settle',  effect: { cashFrac: -0.2, trust: 6 } },
        { id: 'appeal',  effect: { cashFrac: -0.1, vec: { reg: 14 } } },
        { id: 'ignore',  effect: { penaltySec: 90, trust: -5 } } ] },
      { id: 'c_data2', vector: 'data', choices: [
        { id: 'optout',  effect: { cashFrac: -0.13, trust: 5 } },
        { id: 'sell',    effect: { cashGift: 120, trust: -14, vec: { reg: 18 } } },
        { id: 'ignore',  effect: { penaltySec: 90 } } ] }
    ],
    // news decisions (two-choice) + opportunities (single act). gated behind progress.
    news: [
      { id: 'n_oss', kind: 'decision', choices: [
        { id: 'match',  effect: { cashFrac: -0.2, trust: 4 } },
        { id: 'ignore', effect: { penaltySec: 45 } } ] },
      { id: 'n_poach', kind: 'decision', choices: [
        { id: 'counter', effect: { cashFrac: -0.15 } },
        { id: 'letgo',   effect: { vec: { sec: 12 } } } ] },
      { id: 'n_round', kind: 'opportunity', choices: [
        { id: 'raise', effect: { cashGift: 240, trust: -3 } } ] },
      { id: 'n_chip', kind: 'opportunity', choices: [
        { id: 'buy', effect: { allMult: 1.05 } } ] },
      { id: 'n_grant', kind: 'opportunity', req: { trust: 70 }, choices: [
        { id: 'accept', effect: { cashGift: 300, trust: 3 } } ] },
      { id: 'n_defense', kind: 'opportunity', req: { trust: 85 }, choices: [
        { id: 'sign', effect: { cashGift: 420, vec: { reg: 12 } } } ] },
      { id: 'n_viral', kind: 'decision', choices: [
        { id: 'lean',  effect: { trust: -6, cashGift: 180, vec: { reg: 10 } } },
        { id: 'damp',  effect: { trust: 5 } } ] },
      { id: 'n_whistle', kind: 'decision', choices: [
        { id: 'address', effect: { cashFrac: -0.12, trust: 8 } },
        { id: 'silence', effect: { trust: -15, vec: { sec: 14 } } } ] },
      { id: 'n_audit', kind: 'opportunity', choices: [
        { id: 'invite', effect: { trust: 7, cashFrac: -0.08 } } ] }
    ]
  };

  // ===== DECISION ENGINE (Phase 2) — events as DATA ======================
  // The decision engine reads these declarative rows; one generic runtime fires
  // them (see game.js evalCond/decision pacer). NOTE: the older C.EVENTS object
  // above is the world/industry-frenzy system and is UNRELATED — decision events
  // live under C.DECISIONS to avoid any collision.
  //
  // Schema (design §4):
  //   { id, act:[..], category, weight, cooldown_sec, once, default_option?,
  //     priority:'interrupt'|'bankable'|'ambient',
  //     trigger:{<cond-tree>}, weight_mods:[{factor, when:{<cond-tree>}}],
  //     options:[{ id, trigger?, tooltip_meters?, effects:{<applyEffect grammar>} }] }
  // i18n keys: {id}_t (title), {id}_d (desc), {id}_{optionId} (option label).
  //
  // ⚠ PHASE 2 = ~6 TEST events to exercise the engine. Phase 3 expands to 70–90
  //   real events from DESIGN-events-catalog.md. Each test row is marked TEST.
  var DECISIONS_PACING = {
    FIRST_DELAY: 25,        // no decision before this much ACTIVE playtime (sec)
    FIRST_INTERVAL_MIN: 35, // onboarding: the FIRST decision lands ~25+35..25+65s = 60–90s in
    FIRST_INTERVAL_MAX: 65, // (settles to the normal cadence below once one has fired)
    INTERVAL_MIN: 120,      // ~one decision per 2–4 min of active play (Act-scaled below)
    INTERVAL_MAX: 240,
    ACT_SPEEDUP: 0.12,      // each act shortens the interval by this fraction (later acts = busier)
    QUIET_FLOOR: 45,        // hard minimum gap between ANY two decisions (a breathing floor)
    CATEGORY_COOLDOWN: 90,  // per-category cooldown (no two of one category back-to-back, sec)
    NO_REPEAT_SEC: 60,      // global "no repeat within a day" — per-event re-fire floor (1 day = DAY_SEC)
    BANKABLE_AUTO_SEC: 240  // a bankable decision auto-resolves (default option) after this if ignored
  };
  // ===== EXECUTIVE / MANAGING DIRECTOR ladder (DESIGN-exec-team.md) =====
  // ONE slot, a long tier ladder. While you're AWAY, your director auto-resolves the
  // decisions that "would have fired" — quality scales with `judgment` (0..100) and your
  // MANDATE. Cost + recruit time + judgment escalate up the ladder; the TOP tier is gated
  // by high valuation + high trust + a huge signing package + a multi-day timer so reaching
  // it is the ~15-real-day "white whale" of the monthly arc.
  //   { id, name(i18n key), judgment, costCash, recruitSec, gate?{valuation,trust,modelGen}, perk? }
  // perk = a small ONLINE bonus (decoration; honored where noted). recruitSec is REAL wall-clock.
  var H = 3600;  // one real hour, in seconds (recruit timers are real-time)
  var EXECS = [
    { id: 'exec_t1',  name: 'exec_t1_name',  judgment: 10, costCash: 250,        recruitSec: 120 },
    { id: 'exec_t2',  name: 'exec_t2_name',  judgment: 20, costCash: 1500,       recruitSec: 300,        perk: { buildSpeed: 0.03 } },
    { id: 'exec_t3',  name: 'exec_t3_name',  judgment: 30, costCash: 9000,       recruitSec: 0.75 * H,   perk: { buildSpeed: 0.06 } },
    { id: 'exec_t4',  name: 'exec_t4_name',  judgment: 40, costCash: 55000,      recruitSec: 2 * H,      perk: { researchSpeed: 0.05 } },
    { id: 'exec_t5',  name: 'exec_t5_name',  judgment: 50, costCash: 320000,     recruitSec: 5 * H,      perk: { researchSpeed: 0.08 } },
    { id: 'exec_t6',  name: 'exec_t6_name',  judgment: 62, costCash: 1.9e6,      recruitSec: 12 * H,     perk: { researchSpeed: 0.10 } },
    { id: 'exec_t7',  name: 'exec_t7_name',  judgment: 72, costCash: 1.1e7,      recruitSec: 22 * H,     perk: { riskDamp: 0.06 } },
    { id: 'exec_t8',  name: 'exec_t8_name',  judgment: 82, costCash: 6.5e7,      recruitSec: 40 * H,     perk: { dealBonus: 0.10 },
      gate: { valuation: 5e8, trust: 60 } },
    { id: 'exec_t9',  name: 'exec_t9_name',  judgment: 90, costCash: 4e8,        recruitSec: 72 * H,     perk: { dealBonus: 0.15 },
      gate: { valuation: 5e9, trust: 70, modelGen: 4 } },
    { id: 'exec_t10', name: 'exec_t10_name', judgment: 99, costCash: 1e8 /*signing bonus shown separately*/, recruitSec: 96 * H,
      perk: { dealBonus: 0.20, researchSpeed: 0.10 },
      gate: { valuation: 5e10, trust: 80, modelGen: 6 }, legendary: true,
      signing: 2.5e9 /*$2.5B signing package on TOP of base cost*/ },
  ];
  // offline delegation: how often a decision "would have fired" while away (avg real sec).
  // N resolved = clamp(floor(awaySec / this), 0, MAX).
  var EXECS_OFFLINE = { AVG_DECISION_SEC: 1800, MAX_RESOLVED: 6 };

  // PHASE 3 WAVE 1 — ~40 real decision events (≈4 per category × 10 catalog cats).
  // Reskinned from DESIGN-events-catalog.md (130 real situations). Rivals = Helion /
  // Cerebra / OmniNet. Balance rule enforced: every option costs something, trade-offs
  // cross OPPOSED meters (speed/share/valuation ↑ ↔ align ↓ / risk ↑), trust gates the
  // virtuous path. Three multi-stage ARCS use schedule() (ids tagged ARC-* below).
  // The two catalog topics flagged sensitive (whistleblower death, teen-suicide case)
  // are deliberately SKIPPED in this wave. i18n: {id}_t/_d + {id}_{optionId} (EN+RU).
  var DECISIONS = [

    // ===================== EARLY GAME — ACT 0/1 (garage & startup) =====================
    // Onboarding-grade dilemmas with LOW or no gates so the FIRST decision surfaces fast
    // on a fresh game (act 0 = garage). Mostly bankable, a couple interrupt, a couple
    // ambient. Effects stay modest (garage economy is tiny). i18n: {id}_t/_d + per-option.
    {
      id: 'dec_eq_split', act: [0, 1], category: 'funding', weight: 130,
      cooldown_sec: 0, once: true, priority: 'interrupt',
      trigger: { 'meter.act': '<=1' },
      options: [
        { id: 'equal', tooltip_meters: ['trust'],
          effects: { meter: { trust: '+4' }, set_var: { founder_goodwill: '+1' } } },
        { id: 'control', tooltip_meters: ['trust', 'cash'],
          effects: { resource: { cash: '+40' }, meter: { trust: '-3' }, set_var: { founder_friction: '+1' } } }
      ]
    },
    {
      id: 'dec_first_hire', act: [0, 1], category: 'talent', weight: 120,
      cooldown_sec: 200, once: true, priority: 'bankable', default_option: 'generalist',
      trigger: { 'resource.compute': '>=10' },
      options: [
        { id: 'generalist', tooltip_meters: ['cash', 'researchers'],
          effects: { resource: { cash: '-40', researchers: '+1' } } },
        { id: 'specialist', tooltip_meters: ['cash', 'researchers', 'trust'],
          effects: { resource: { cash: '-90', researchers: '+1' }, meter: { trust: '+2' } } },
        { id: 'solo', tooltip_meters: ['cash', 'risk'],
          effects: { resource: { cash: '+20' }, set_var: { burnout_debt: '+1' } } }
      ]
    },
    {
      id: 'dec_ramen_or_raise', act: [0, 1], category: 'funding', weight: 110,
      cooldown_sec: 220, once: false, priority: 'bankable', default_option: 'ramen',
      trigger: { 'resource.compute': '>=15' },
      options: [
        { id: 'ramen', tooltip_meters: ['trust'],
          effects: { meter: { trust: '+2' }, set_var: { indie_cred: '+1' } } },
        { id: 'raise', tooltip_meters: ['cash', 'trust'],
          effects: { resource: { cash: '+120' }, meter: { trust: '-2' }, set_var: { dilution: '+1' } } }
      ]
    },
    {
      id: 'dec_first_customer', act: [0, 1], category: 'product', weight: 105,
      cooldown_sec: 220, once: true, priority: 'interrupt',
      trigger: { 'resource.compute': '>=25' },
      options: [
        { id: 'build_it', tooltip_meters: ['cash', 'trust', 'risk'],
          effects: { resource: { cash: '+150' }, meter: { trust: '-2' }, vec: { sec: 6 }, set_var: { tech_debt: '+1' } } },
        { id: 'say_no', tooltip_meters: ['cash', 'trust'],
          effects: { meter: { trust: '+3' } } }
      ]
    },
    {
      id: 'dec_vanity_metric', act: [0, 1, 2], category: 'funding', weight: 95,
      cooldown_sec: 220, once: false, priority: 'bankable', default_option: 'honest',
      trigger: { 'resource.compute': '>=20' },
      options: [
        { id: 'juice', tooltip_meters: ['cash', 'trust', 'risk'],
          effects: { resource: { cash: '+80' }, meter: { trust: '-4' }, set_var: { vanity_debt: '+1' } } },
        { id: 'honest', tooltip_meters: ['trust'],
          effects: { meter: { trust: '+2' } } }
      ]
    },
    {
      id: 'dec_name_model', act: [0, 1], category: 'pr', weight: 100,
      cooldown_sec: 0, once: true, priority: 'ambient', default_option: 'sensible',
      trigger: { 'resource.compute': '>=12' },
      options: [
        { id: 'sensible', tooltip_meters: ['trust'],
          effects: { meter: { trust: '+1' } } },
        { id: 'edgy', tooltip_meters: ['trust', 'risk'],
          effects: { meter: { trust: '-1' }, vec: { sec: 3 } } }
      ]
    },
    {
      id: 'dec_viral_demo', act: [0, 1], category: 'pr', weight: 100,
      cooldown_sec: 200, once: false, priority: 'interrupt',
      trigger: { 'resource.compute': '>=30' },
      options: [
        { id: 'overpromise', tooltip_meters: ['cash', 'trust', 'risk'],
          effects: { resource: { cash: '+90' }, meter: { trust: '-3' }, set_var: { hype_debt: '+1' },
                     schedule: { event: 'dec_demo_backlash', delaySec: 110, chance: 0.5, callback: 'callback_hype' } } },
        { id: 'caveat', tooltip_meters: ['cash', 'trust'],
          effects: { resource: { cash: '+25' }, meter: { trust: '+2' } } }
      ]
    },
    {
      id: 'dec_demo_backlash', act: [0, 1, 2, 3], category: 'pr', weight: 0,
      cooldown_sec: 0, once: false, priority: 'scheduled', _callback: true,
      trigger: { OR: [] },
      options: [
        { id: 'apologize', tooltip_meters: ['trust', 'cash'],
          effects: { resource: { cash: '-30' }, meter: { trust: '+3' } } },
        { id: 'double_down', tooltip_meters: ['trust', 'risk'],
          effects: { meter: { trust: '-4' }, vec: { sec: 6 } } }
      ]
    },
    {
      id: 'dec_open_or_closed', act: [0, 1], category: 'opensource', weight: 95,
      cooldown_sec: 220, once: true, priority: 'bankable', default_option: 'closed',
      trigger: { 'resource.compute': '>=18' },
      options: [
        { id: 'open', tooltip_meters: ['trust', 'risk'],
          effects: { meter: { trust: '+5' }, vec: { sec: 4 }, set_flag: 'oss_lab' } },
        { id: 'closed', tooltip_meters: ['cash', 'trust'],
          effects: { resource: { cash: '+30' }, meter: { trust: '-1' } } }
      ]
    },
    {
      id: 'dec_journalist', act: [0, 1, 2], category: 'pr', weight: 90,
      cooldown_sec: 240, once: false, priority: 'bankable', default_option: 'decline',
      trigger: { 'resource.compute': '>=22' },
      options: [
        { id: 'interview', tooltip_meters: ['trust', 'risk'],
          effects: { meter: { trust: '+4' }, vec: { reg: 3 } } },
        { id: 'decline', tooltip_meters: ['trust'],
          effects: { meter: { trust: '-1' } } }
      ]
    },
    {
      id: 'dec_gpu_spike', act: [0, 1, 2], category: 'compute', weight: 100,
      cooldown_sec: 200, once: false, priority: 'bankable', default_option: 'absorb',
      trigger: { 'resource.compute': '>=14' },
      weight_mods: [{ factor: 1.4, when: { 'resource.compute': '>=200' } }],
      options: [
        { id: 'absorb', tooltip_meters: ['cash', 'compute'],
          effects: { resource: { cash: '-60', compute: '+30' } } },
        { id: 'pause', tooltip_meters: ['compute', 'trust'],
          effects: { meter: { trust: '-1' }, set_var: { compute_debt: '+1' } } }
      ]
    },
    {
      id: 'dec_poach_engineer', act: [0, 1], category: 'talent', weight: 110,
      cooldown_sec: 180, once: false, priority: 'interrupt',
      trigger: { 'resource.researchers': '>=1' },
      options: [
        { id: 'match_offer', tooltip_meters: ['cash', 'researchers'],
          effects: { resource: { cash: '-110' } } },
        { id: 'let_walk', tooltip_meters: ['researchers', 'risk'],
          effects: { resource: { researchers: '-1' }, vec: { sec: 5 } } },
        { id: 'equity_plea', tooltip_meters: ['trust'],
          effects: { meter: { trust: '+1' }, set_var: { dilution: '+1' } } }
      ]
    },
    {
      id: 'dec_cloud_credits', act: [0, 1], category: 'compute', weight: 95,
      cooldown_sec: 240, once: true, priority: 'bankable', default_option: 'decline',
      trigger: { 'resource.compute': '>=16' },
      options: [
        { id: 'accept', tooltip_meters: ['cash', 'compute', 'trust'],
          effects: { resource: { cash: '+40', compute: '+60' }, meter: { trust: '-2' }, set_flag: 'cloud_locked' } },
        { id: 'decline', tooltip_meters: ['compute', 'trust'],
          effects: { meter: { trust: '+1' } } }
      ]
    },

    // ========================= REGULATION (4) =============================
    // ARC-REG: a one-shot safe-harbor pledge → its delayed disclosure bill.
    {
      id: 'dec_reg_eu_act', act: [2, 3], category: 'regulation', weight: 95,
      cooldown_sec: 240, once: false, priority: 'interrupt',
      trigger: { AND: [{ 'meter.marketShare': '>=8' }, { 'meter.vec.reg': '>=20' }] },
      weight_mods: [{ factor: 2.0, when: { 'meter.vec.reg': '>=55' } }],
      options: [
        { id: 'comply', tooltip_meters: ['cash', 'trust', 'risk'],
          effects: { resource: { cash: '-300' }, meter: { trust: '+5', marketShare: '-2' }, vec: { reg: -16 } } },
        { id: 'minimal', tooltip_meters: ['cash', 'risk'],
          effects: { resource: { cash: '-90' }, vec: { reg: -4 }, set_var: { reg_debt: '+1' } } },
        { id: 'defy', tooltip_meters: ['marketShare', 'risk', 'trust'],
          effects: { meter: { marketShare: '+5', trust: '-3' }, vec: { reg: 18 },
                     schedule: { event: 'dec_reg_fine_hits', delaySec: 150, chance: 0.5, callback: 'callback_reg_fine' } } }
      ]
    },
    {
      id: 'dec_reg_safe_harbor', act: [2, 3], category: 'regulation', weight: 70,
      cooldown_sec: 300, once: true, priority: 'bankable', default_option: 'decline',
      trigger: { AND: [{ 'meter.marketShare': '>=10' }, { 'meter.trust': '>=35' }] },
      options: [
        { id: 'sign', tooltip_meters: ['trust', 'risk', 'marketShare'],
          effects: { meter: { trust: '+6', marketShare: '-2' }, vec: { reg: -10 }, set_flag: 'signed_code',
                     schedule: { event: 'dec_reg_disclosure_bill', delaySec: 180, chance: 0.8, callback: 'callback_disclosure' } } },
        { id: 'decline', tooltip_meters: ['risk', 'trust'],
          effects: { meter: { trust: '-2' }, vec: { reg: 6 } } }
      ]
    },
    {
      id: 'dec_reg_disclosure_bill', act: [2, 3], category: 'regulation', weight: 0,
      cooldown_sec: 0, once: false, priority: 'scheduled', _callback: true,
      trigger: { OR: [] },
      options: [
        { id: 'disclose', tooltip_meters: ['trust', 'marketShare', 'risk'],
          effects: { meter: { trust: '+5', marketShare: '-4' }, vec: { data: 8, reg: -8 } } },
        { id: 'redact', tooltip_meters: ['marketShare', 'risk', 'trust'],
          effects: { meter: { marketShare: '+2', trust: '-4' }, vec: { reg: 12 } } }
      ]
    },
    {
      id: 'dec_reg_patchwork', act: [2, 3], category: 'regulation', weight: 80,
      cooldown_sec: 220, once: false, priority: 'bankable', default_option: 'comply_all',
      trigger: { 'meter.marketShare': '>=12' },
      options: [
        { id: 'comply_all', tooltip_meters: ['cash', 'risk'],
          effects: { resource: { cash: '-180' }, vec: { reg: -8 } } },
        { id: 'geoblock', tooltip_meters: ['marketShare', 'trust'],
          effects: { meter: { marketShare: '-3', trust: '+2' }, vec: { reg: -4 } } },
        { id: 'ignore', tooltip_meters: ['marketShare', 'risk'],
          effects: { meter: { marketShare: '+3' }, vec: { reg: 10 }, set_var: { reg_debt: '+1' } } }
      ]
    },
    {
      id: 'dec_reg_fine_hits', act: [2, 3], category: 'regulation', weight: 0,
      cooldown_sec: 0, once: false, priority: 'scheduled', _callback: true,
      trigger: { OR: [] },
      options: [
        { id: 'pay', tooltip_meters: ['cash', 'trust', 'risk'],
          effects: { cashFrac: -0.10, meter: { trust: '+2' }, vec: { reg: -12 } } },
        { id: 'appeal', tooltip_meters: ['cash', 'risk', 'trust'],
          effects: { resource: { cash: '-120' }, meter: { trust: '-3' }, vec: { reg: 8 } } }
      ]
    },

    // ========================= COMPUTE / CHIPS (4) =======================
    {
      id: 'dec_chip_takeorpay', act: [2, 3], category: 'compute', weight: 90,
      cooldown_sec: 240, once: false, priority: 'interrupt',
      trigger: { 'resource.compute': '>=200' },
      weight_mods: [{ factor: 1.6, when: { 'meter.marketShare': '>=20' } }],
      options: [
        { id: 'lockin', tooltip_meters: ['cash', 'compute', 'risk'],
          effects: { resource: { cash: '-500', compute: '+400' }, set_var: { capex_debt: '+1' } } },
        { id: 'wait', tooltip_meters: ['compute', 'marketShare', 'risk'],
          effects: { meter: { marketShare: '-2' }, vec: { cap: -4 }, rival_effect: { helion: { agi: 1.5 } } } },
        { id: 'efficiency', tooltip_meters: ['cash', 'compute', 'align'],
          effects: { resource: { cash: '-150', compute: '+120' }, meter: { align: '+1' } } }
      ]
    },
    {
      id: 'dec_chip_datacenter', act: [2, 3], category: 'compute', weight: 75,
      cooldown_sec: 260, once: false, priority: 'bankable', default_option: 'permits',
      trigger: { 'resource.compute': '>=400' },
      options: [
        { id: 'permits', tooltip_meters: ['cash', 'compute', 'trust'],
          effects: { resource: { cash: '-260', compute: '+180' }, meter: { trust: '+2' } } },
        { id: 'fasttrack', tooltip_meters: ['compute', 'trust', 'risk'],
          effects: { resource: { compute: '+320' }, meter: { trust: '-4' }, vec: { reg: 10 },
                     schedule: { event: 'dec_chip_grid_backlash', delaySec: 160, chance: 0.5 } } }
      ]
    },
    {
      id: 'dec_chip_grid_backlash', act: [2, 3], category: 'compute', weight: 0,
      cooldown_sec: 0, once: false, priority: 'scheduled', _callback: true,
      trigger: { OR: [] },
      options: [
        { id: 'subsidize', tooltip_meters: ['cash', 'trust'],
          effects: { resource: { cash: '-220' }, meter: { trust: '+4' } } },
        { id: 'stonewall', tooltip_meters: ['trust', 'risk'],
          effects: { meter: { trust: '-6' }, vec: { reg: 12 } } }
      ]
    },
    {
      id: 'dec_chip_custom_silicon', act: [3], category: 'compute', weight: 60,
      cooldown_sec: 300, once: true, priority: 'bankable', default_option: 'stay',
      trigger: { AND: [{ 'resource.compute': '>=2000' }, { 'resource.cash': '>=600' }] },
      options: [
        { id: 'build', tooltip_meters: ['cash', 'compute', 'risk'],
          effects: { resource: { cash: '-600' }, meter: { valuation: '+8' },
                     buff: { key: 'silicon', mult: 1.15, days: 6 }, set_var: { capex_debt: '+1' } } },
        { id: 'stay', tooltip_meters: ['cash', 'compute'],
          effects: { resource: { compute: '+150' } } }
      ]
    },
    {
      id: 'dec_chip_deepseek_shock', act: [2, 3], category: 'compute', weight: 55,
      cooldown_sec: 280, once: true, priority: 'interrupt',
      trigger: { 'meter.marketShare': '>=18' },
      options: [
        { id: 'pivot', tooltip_meters: ['cash', 'compute', 'align'],
          effects: { resource: { cash: '-200' }, meter: { align: '+2', valuation: '-5' }, buff: { key: 'efficiency', mult: 1.1, days: 5 } } },
        { id: 'doubledown', tooltip_meters: ['compute', 'valuation', 'risk'],
          effects: { resource: { compute: '+260' }, meter: { valuation: '+4', marketShare: '+3' }, vec: { cap: 8 } } }
      ]
    },

    // ========================= TALENT (4) ================================
    {
      id: 'dec_talent_poach', act: [1, 2, 3], category: 'talent', weight: 100,
      cooldown_sec: 180, once: false, priority: 'bankable', default_option: 'counter',
      trigger: { 'resource.researchers': '>=1' },
      weight_mods: [{ factor: 1.4, when: { 'meter.marketShare': '>=15' } }],
      options: [
        { id: 'counter', tooltip_meters: ['cash', 'researchers'],
          effects: { resource: { cash: '-150' } } },
        { id: 'letgo', tooltip_meters: ['researchers', 'risk'],
          effects: { resource: { researchers: '-1' }, vec: { sec: 8 }, rival_effect: { cerebra: { agi: 1 } } } },
        { id: 'raid', tooltip_meters: ['cash', 'researchers', 'trust'],
          effects: { resource: { cash: '-300', researchers: '+1' }, meter: { trust: '-3' } } }
      ]
    },
    {
      id: 'dec_talent_megapackage', act: [2, 3], category: 'talent', weight: 70,
      cooldown_sec: 240, once: false, priority: 'interrupt',
      trigger: { AND: [{ 'resource.cash': '>=400' }, { 'meter.marketShare': '>=18' }] },
      options: [
        { id: 'match', tooltip_meters: ['cash', 'researchers', 'valuation'],
          effects: { resource: { cash: '-450', researchers: '+1' }, meter: { valuation: '+3' } } },
        { id: 'walk', tooltip_meters: ['researchers', 'risk', 'cash'],
          effects: { vec: { cap: 6 }, rival_effect: { helion: { agi: 2 } } } }
      ]
    },
    {
      id: 'dec_talent_acquihire', act: [3], category: 'talent', weight: 55,
      cooldown_sec: 300, once: true, priority: 'bankable', default_option: 'pass',
      trigger: { 'resource.cash': '>=800' },
      options: [
        { id: 'absorb', tooltip_meters: ['cash', 'researchers', 'risk'],
          effects: { resource: { cash: '-800', researchers: '+2' }, meter: { marketShare: '+3' }, vec: { reg: 10 } } },
        { id: 'pass', tooltip_meters: ['cash', 'trust'],
          effects: { meter: { trust: '+2' } } }
      ]
    },
    {
      id: 'dec_talent_noncompete', act: [1, 2], category: 'talent', weight: 65,
      cooldown_sec: 200, once: false, priority: 'ambient', default_option: 'reasonable',
      trigger: { 'resource.researchers': '>=2' },
      options: [
        { id: 'reasonable', tooltip_meters: ['trust'],
          effects: { meter: { trust: '+1' } } },
        { id: 'gardenleave', tooltip_meters: ['cash', 'trust'],
          effects: { resource: { cash: '-60' }, meter: { trust: '-2' } } }
      ]
    },

    // ========================= SAFETY / INCIDENTS (4) ====================
    {
      id: 'dec_safety_review', act: [2, 3], category: 'safety', weight: 85,
      cooldown_sec: 200, once: false, priority: 'bankable', default_option: 'review',
      trigger: { 'resource.modelGen': '>=2' },
      weight_mods: [{ factor: 2.0, when: { 'meter.risk': '>=50' } }],
      options: [
        { id: 'review', tooltip_meters: ['cash', 'risk', 'align'],
          effects: { resource: { cash: '-120' }, meter: { align: '+2' }, vec: { cap: -8 } } },
        { id: 'ship', tooltip_meters: ['marketShare', 'risk', 'align'],
          effects: { meter: { marketShare: '+4', align: '-1' }, vec: { cap: 10 }, set_var: { safety_debt: '+1' },
                     schedule: { event: 'dec_safety_incident_hits', delaySec: 140, chance: 0.45, callback: 'callback_incident' } } }
      ]
    },
    {
      id: 'dec_safety_pledge', act: [2, 3], category: 'safety', weight: 60,
      cooldown_sec: 300, once: true, priority: 'interrupt',
      trigger: { AND: [{ 'meter.marketShare': '>=15' }, { 'meter.trust': '>=30' }] },
      options: [
        { id: 'honor', tooltip_meters: ['compute', 'align', 'trust'],
          effects: { resource: { compute: '-200' }, meter: { align: '+3', trust: '+5' }, vec: { cap: -10 } } },
        { id: 'dissolve', tooltip_meters: ['compute', 'marketShare', 'trust'],
          effects: { resource: { compute: '+200' }, meter: { marketShare: '+5', trust: '-6', align: '-2' }, vec: { cap: 12 } } }
      ]
    },
    {
      id: 'dec_safety_jailbreak', act: [1, 2, 3], category: 'safety', weight: 75,
      cooldown_sec: 200, once: false, priority: 'bankable', default_option: 'patch',
      trigger: { 'resource.modelGen': '>=1' },
      weight_mods: [{ factor: 1.5, when: { 'meter.vec.sec': '>=40' } }],
      options: [
        { id: 'patch', tooltip_meters: ['cash', 'risk'],
          effects: { resource: { cash: '-90' }, vec: { sec: -10 } } },
        { id: 'spin', tooltip_meters: ['trust', 'risk'],
          effects: { meter: { trust: '-3' }, vec: { sec: 6 } } }
      ]
    },
    {
      id: 'dec_safety_incident_hits', act: [2, 3], category: 'safety', weight: 0,
      cooldown_sec: 0, once: false, priority: 'scheduled', _callback: true,
      trigger: { OR: [] },
      options: [
        { id: 'recall', tooltip_meters: ['cash', 'marketShare', 'trust'],
          effects: { resource: { cash: '-200' }, meter: { marketShare: '-4', trust: '+4' }, vec: { cap: -8 } } },
        { id: 'deny', tooltip_meters: ['trust', 'risk'],
          effects: { meter: { trust: '-8' }, vec: { cap: 8, reg: 10 } } }
      ]
    },

    // ========================= LEGAL (4) =================================
    // ARC-COPYRIGHT: scrape data → (delayed) lawsuit → settle-or-fight.
    {
      id: 'dec_data_dilemma', act: [1, 2], category: 'legal', weight: 100,
      cooldown_sec: 240, once: false, priority: 'interrupt',
      trigger: { AND: [{ 'resource.compute': '>=20' }, { NOT: { flag: 'sued_copyright' } }] },
      weight_mods: [{ factor: 2.0, when: { 'meter.risk': '>=60' } }],
      options: [
        { id: 'pirate', tooltip_meters: ['marketShare', 'risk', 'cash'],
          effects: { meter: { marketShare: '+6' }, vec: { data: 12 }, set_var: { legal_debt: '+1' },
                     schedule: { event: 'dec_lawsuit_hits', delaySec: 120, chance: 0.6, callback: 'callback_lawsuit' } } },
        { id: 'license', tooltip_meters: ['cash', 'trust', 'risk'],
          effects: { resource: { cash: '-200' }, meter: { trust: '+4', marketShare: '-2' }, vec: { data: -6 } } }
      ]
    },
    {
      id: 'dec_lawsuit_hits', act: [1, 2, 3], category: 'legal', weight: 0,
      cooldown_sec: 0, once: false, priority: 'scheduled', _callback: true,
      trigger: { OR: [] },
      options: [
        { id: 'settle', tooltip_meters: ['cash', 'trust'],
          effects: { resource: { cash: '-350' }, meter: { trust: '+2' }, vec: { data: -4 } } },
        { id: 'fight', tooltip_meters: ['cash', 'risk', 'trust'],
          effects: { resource: { cash: '-150' }, meter: { trust: '-4' }, vec: { reg: 14 }, set_flag: 'sued_copyright' } }
      ]
    },
    {
      id: 'dec_legal_logs', act: [2, 3], category: 'legal', weight: 70,
      cooldown_sec: 240, once: false, priority: 'interrupt',
      trigger: { AND: [{ 'meter.marketShare': '>=15' }, { 'resource.modelGen': '>=3' }] },
      options: [
        { id: 'preserve', tooltip_meters: ['trust', 'risk', 'marketShare'],
          effects: { meter: { trust: '-5', marketShare: '-2' }, vec: { reg: -6 } } },
        { id: 'resist', tooltip_meters: ['cash', 'trust', 'risk'],
          effects: { resource: { cash: '-180' }, meter: { trust: '+4' }, vec: { reg: 10 } } }
      ]
    },
    {
      id: 'dec_legal_defamation', act: [2, 3], category: 'legal', weight: 60,
      cooldown_sec: 220, once: false, priority: 'bankable', default_option: 'disclaim',
      trigger: { 'resource.modelGen': '>=2' },
      options: [
        { id: 'disclaim', tooltip_meters: ['cash', 'marketShare', 'trust'],
          effects: { resource: { cash: '-60' }, meter: { marketShare: '-1', trust: '+1' } } },
        { id: 'litigate', tooltip_meters: ['cash', 'risk', 'trust'],
          effects: { resource: { cash: '-160' }, meter: { trust: '-2' }, vec: { reg: 6 } } }
      ]
    },

    // ========================= OPEN-SOURCE (4) ===========================
    {
      id: 'dec_oss_release', act: [1, 2, 3], category: 'opensource', weight: 65,
      cooldown_sec: 200, once: false, priority: 'bankable', default_option: 'gated',
      trigger: { 'resource.modelGen': '>=2' },
      options: [
        { id: 'open', tooltip_meters: ['trust', 'marketShare', 'risk'],
          effects: { meter: { trust: '+5', marketShare: '-3' }, vec: { sec: 8 }, rival_effect: { all: { agi: 1 } } } },
        { id: 'gated', tooltip_meters: ['marketShare', 'trust'],
          effects: { meter: { marketShare: '+2', trust: '-1' } } }
      ]
    },
    {
      id: 'dec_oss_weights_leak', act: [2, 3], category: 'opensource', weight: 55,
      cooldown_sec: 260, once: false, priority: 'interrupt',
      trigger: { AND: [{ 'resource.modelGen': '>=3' }, { 'meter.vec.sec': '>=30' }] },
      options: [
        { id: 'embrace', tooltip_meters: ['trust', 'marketShare', 'risk'],
          effects: { meter: { trust: '+3', marketShare: '-2' }, vec: { sec: 6 }, rival_effect: { all: { agi: 1.5 } } } },
        { id: 'legal', tooltip_meters: ['cash', 'risk', 'trust'],
          effects: { resource: { cash: '-140' }, meter: { trust: '-2' }, vec: { sec: -6, reg: 6 } } }
      ]
    },
    {
      id: 'dec_oss_distill_claim', act: [2, 3], category: 'opensource', weight: 50,
      cooldown_sec: 240, once: false, priority: 'bankable', default_option: 'ignore',
      trigger: { 'meter.marketShare': '>=20' },
      options: [
        { id: 'accuse', tooltip_meters: ['marketShare', 'trust', 'risk'],
          effects: { meter: { marketShare: '+2', trust: '-3' }, vec: { reg: 8 } } },
        { id: 'ignore', tooltip_meters: ['marketShare', 'trust'],
          effects: { meter: { marketShare: '-2', trust: '+1' }, rival_effect: { omninet: { share: 1 } } } }
      ]
    },
    {
      id: 'dec_oss_pricewar', act: [2, 3], category: 'opensource', weight: 70,
      cooldown_sec: 220, once: false, priority: 'bankable', default_option: 'hold',
      trigger: { 'meter.marketShare': '>=12' },
      weight_mods: [{ factor: 1.4, when: { 'meter.marketShare': '>=25' } }],
      options: [
        { id: 'cut', tooltip_meters: ['cash', 'marketShare', 'risk'],
          effects: { cashFrac: -0.08, meter: { marketShare: '+5' }, set_var: { runway_debt: '+1' } } },
        { id: 'hold', tooltip_meters: ['marketShare', 'cash'],
          effects: { meter: { marketShare: '-2' }, rival_effect: { helion: { share: 1 } } } }
      ]
    },

    // ========================= PRODUCT / MARKET (4) ======================
    {
      id: 'dec_prod_demo', act: [1, 2], category: 'product', weight: 85,
      cooldown_sec: 200, once: false, priority: 'bankable', default_option: 'rehearse',
      trigger: { 'resource.modelGen': '>=1' },
      options: [
        { id: 'rehearse', tooltip_meters: ['cash', 'trust'],
          effects: { resource: { cash: '-80' }, meter: { trust: '+2' } } },
        { id: 'wing_it', tooltip_meters: ['marketShare', 'trust', 'valuation'],
          effects: { meter: { marketShare: '+3', trust: '-4', valuation: '-3' } } }
      ]
    },
    {
      id: 'dec_prod_sycophancy', act: [2, 3], category: 'product', weight: 70,
      cooldown_sec: 220, once: false, priority: 'bankable', default_option: 'tune_down',
      trigger: { 'resource.modelGen': '>=3' },
      options: [
        { id: 'tune_down', tooltip_meters: ['marketShare', 'align', 'trust'],
          effects: { meter: { marketShare: '-2', align: '+2', trust: '+2' } } },
        { id: 'leave_it', tooltip_meters: ['marketShare', 'align', 'risk'],
          effects: { meter: { marketShare: '+3', align: '-2' }, vec: { cap: 6 } } }
      ]
    },
    {
      id: 'dec_prod_viral_trend', act: [2, 3], category: 'product', weight: 75,
      cooldown_sec: 200, once: false, priority: 'interrupt',
      trigger: { AND: [{ 'resource.modelGen': '>=3' }, { 'resource.compute': '>=500' }] },
      options: [
        { id: 'ride', tooltip_meters: ['compute', 'marketShare', 'risk'],
          effects: { resource: { compute: '-200' }, meter: { marketShare: '+6' }, vec: { sec: 6 } } },
        { id: 'ratelimit', tooltip_meters: ['marketShare', 'trust', 'compute'],
          effects: { meter: { marketShare: '+1', trust: '+2' } } }
      ]
    },
    {
      id: 'dec_prod_deprecate', act: [3], category: 'product', weight: 55,
      cooldown_sec: 240, once: false, priority: 'ambient', default_option: 'keep',
      trigger: { 'resource.modelGen': '>=5' },
      options: [
        { id: 'keep', tooltip_meters: ['cash', 'trust'],
          effects: { resource: { cash: '-50' }, meter: { trust: '+1' } } },
        { id: 'sunset', tooltip_meters: ['cash', 'trust'],
          effects: { meter: { trust: '-2' } } }
      ]
    },

    // ========================= FUNDING (4) ===============================
    // ARC-BOARD: take a giant's strategic round → (delayed) board reckoning.
    {
      id: 'dec_fund_megaround', act: [1, 2], category: 'funding', weight: 80,
      cooldown_sec: 280, once: true, priority: 'interrupt',
      trigger: { AND: [{ 'resource.modelGen': '>=2' }, { 'meter.marketShare': '>=8' }] },
      options: [
        { id: 'take_giant', tooltip_meters: ['cash', 'valuation', 'risk'],
          effects: { resource: { cash: '+600' }, meter: { valuation: '+10', marketShare: '+2' }, set_flag: 'giant_backed',
                     schedule: { event: 'dec_fund_board_saga', delaySec: 200, chance: 0.7, callback: 'callback_board' } } },
        { id: 'small_rounds', tooltip_meters: ['cash', 'trust', 'valuation'],
          effects: { resource: { cash: '+250' }, meter: { trust: '+3', valuation: '+3' } } }
      ]
    },
    {
      id: 'dec_fund_board_saga', act: [2, 3], category: 'funding', weight: 0,
      cooldown_sec: 0, once: false, priority: 'scheduled', _callback: true,
      trigger: { OR: [] },
      options: [
        { id: 'concede', tooltip_meters: ['valuation', 'align', 'trust'],
          effects: { meter: { valuation: '+4', align: '-2', trust: '-2' }, set_var: { gov_debt: '+1' } } },
        { id: 'fight_board', tooltip_meters: ['cash', 'researchers', 'trust'],
          effects: { resource: { cash: '-200', researchers: '-1' }, meter: { trust: '+3', valuation: '-4' } } }
      ]
    },
    {
      id: 'dec_fund_pbc', act: [2, 3], category: 'funding', weight: 55,
      cooldown_sec: 300, once: true, priority: 'bankable', default_option: 'keep_mission',
      trigger: { AND: [{ 'meter.marketShare': '>=18' }, { 'meter.valuation': '>=40' }] },
      options: [
        { id: 'convert', tooltip_meters: ['cash', 'trust', 'valuation'],
          effects: { resource: { cash: '+400' }, meter: { valuation: '+8', trust: '-5', align: '-1' } } },
        { id: 'keep_mission', tooltip_meters: ['cash', 'trust'],
          effects: { resource: { cash: '-100' }, meter: { trust: '+5' } } }
      ]
    },
    {
      id: 'dec_fund_circular', act: [3], category: 'funding', weight: 50,
      cooldown_sec: 260, once: false, priority: 'ambient', default_option: 'disclose',
      trigger: { 'meter.valuation': '>=60' },
      options: [
        { id: 'disclose', tooltip_meters: ['trust', 'valuation'],
          effects: { meter: { trust: '+2', valuation: '-2' } } },
        { id: 'obscure', tooltip_meters: ['valuation', 'trust'],
          effects: { meter: { valuation: '+3', trust: '-3' } } }
      ]
    },

    // ========================= GEOPOLITICS (4) ===========================
    {
      id: 'dec_geo_exportban', act: [2, 3], category: 'geopolitics', weight: 70,
      cooldown_sec: 260, once: false, priority: 'interrupt',
      trigger: { AND: [{ 'resource.compute': '>=600' }, { 'meter.marketShare': '>=18' }] },
      options: [
        { id: 'pay_tax', tooltip_meters: ['cash', 'compute', 'trust'],
          effects: { cashFrac: -0.15, resource: { compute: '+200' }, meter: { trust: '-2' } } },
        { id: 'comply_ban', tooltip_meters: ['compute', 'marketShare', 'trust'],
          effects: { meter: { marketShare: '-3', trust: '+3' }, rival_effect: { helion: { agi: 1.5 } } } }
      ]
    },
    {
      id: 'dec_geo_smuggle', act: [3], category: 'geopolitics', weight: 50,
      cooldown_sec: 280, once: false, priority: 'bankable', default_option: 'refuse',
      trigger: { AND: [{ 'resource.compute': '>=1000' }, { 'meter.vec.sec': '>=30' }] },
      options: [
        { id: 'gray_market', tooltip_meters: ['compute', 'risk', 'trust'],
          effects: { resource: { compute: '+400' }, meter: { trust: '-5' }, vec: { reg: 14, sec: 8 } } },
        { id: 'refuse', tooltip_meters: ['compute', 'trust'],
          effects: { meter: { trust: '+2' } } }
      ]
    },
    {
      id: 'dec_geo_sovereign', act: [3], category: 'geopolitics', weight: 55,
      cooldown_sec: 280, once: false, priority: 'bankable', default_option: 'decline',
      trigger: { AND: [{ 'meter.marketShare': '>=20' }, { 'resource.cash': '>=400' }] },
      options: [
        { id: 'take_pif', tooltip_meters: ['cash', 'compute', 'trust'],
          effects: { resource: { cash: '+500', compute: '+300' }, meter: { trust: '-6' }, vec: { reg: 8 } } },
        { id: 'decline', tooltip_meters: ['cash', 'trust'],
          effects: { meter: { trust: '+3' } } }
      ]
    },
    {
      id: 'dec_geo_espionage', act: [3], category: 'geopolitics', weight: 45,
      cooldown_sec: 300, once: true, priority: 'interrupt',
      trigger: { AND: [{ 'resource.researchers': '>=4' }, { 'meter.vec.sec': '>=35' }] },
      options: [
        { id: 'surveil', tooltip_meters: ['trust', 'align', 'risk'],
          effects: { meter: { trust: '-4', align: '-1' }, vec: { sec: -12 } } },
        { id: 'trust_team', tooltip_meters: ['risk', 'trust', 'align'],
          effects: { meter: { trust: '+3', align: '+1' }, vec: { sec: 8 } } }
      ]
    },

    // ========================= PR / CULTURE (4) ==========================
    {
      id: 'dec_pr_scarjo', act: [2, 3], category: 'pr', weight: 70,
      cooldown_sec: 220, once: false, priority: 'interrupt',
      trigger: { 'resource.modelGen': '>=3' },
      options: [
        { id: 'ship_voice', tooltip_meters: ['marketShare', 'trust', 'risk'],
          effects: { meter: { marketShare: '+5', trust: '-5' }, vec: { reg: 8 } } },
        { id: 'play_safe', tooltip_meters: ['marketShare', 'trust'],
          effects: { meter: { marketShare: '-1', trust: '+3' } } }
      ]
    },
    {
      id: 'dec_pr_layoffs', act: [2, 3], category: 'pr', weight: 65,
      cooldown_sec: 240, once: false, priority: 'bankable', default_option: 'reskill',
      trigger: { 'meter.marketShare': '>=15' },
      options: [
        { id: 'tout', tooltip_meters: ['valuation', 'trust', 'align'],
          effects: { meter: { valuation: '+3', trust: '-5', align: '-1' } } },
        { id: 'reskill', tooltip_meters: ['cash', 'trust'],
          effects: { resource: { cash: '-120' }, meter: { trust: '+4' } } }
      ]
    },
    {
      id: 'dec_pr_doomer', act: [3], category: 'pr', weight: 55,
      cooldown_sec: 240, once: false, priority: 'ambient', default_option: 'measured',
      trigger: { 'resource.modelGen': '>=5' },
      options: [
        { id: 'measured', tooltip_meters: ['trust', 'align'],
          effects: { meter: { trust: '+2', align: '+1' } } },
        { id: 'dismiss', tooltip_meters: ['marketShare', 'trust'],
          effects: { meter: { marketShare: '+2', trust: '-3' } } }
      ]
    },
    {
      id: 'dec_pr_eacc_manifesto', act: [1, 2], category: 'pr', weight: 60,
      cooldown_sec: 220, once: false, priority: 'bankable', default_option: 'neutral',
      trigger: { 'meter.marketShare': '>=10' },
      options: [
        { id: 'sign_manifesto', tooltip_meters: ['cash', 'trust', 'align'],
          effects: { resource: { cash: '+150' }, meter: { trust: '-4', align: '-1' } } },
        { id: 'neutral', tooltip_meters: ['trust', 'cash'],
          effects: { meter: { trust: '+1' } } }
      ]
    }
  ];

  // ---- Market / investing minigame -------------------------------------
  // R13 anti-printer rework: a BOUNDED RANDOM WALK (REVERT 0) — no mean-reversion
  // edge, so buy-low/sell-high is a coin-flip that loses to the fee on average. A
  // mean-reverting market is provably exploitable (a patient trader compounds the
  // reversion edge into a money printer — the old tuning printed 25,000× in 4h of
  // perfect play). With zero drift + a real 4% fee, even a perfect 4h bot nets only
  // a few× a bankroll on the bounded price band — a flavor skill/luck bonus that can
  // never rival (let alone fund) the exponential generator economy. See BALANCE.md.
  var MARKET = {
    VOL: 0.045,              // per-update volatility (visible ±25% swings)
    REVERT: 0,               // ZERO drift: driftless random walk -> no systematic edge
    BAND: 0.25,              // soft price band: anchor*(1±BAND) keeps prices sane
    TICK: 5,                 // seconds between price updates
    FEE: 0.04,               // 4% per side (8% round-trip) -> churn loses to fees
    assets: [
      { id: 'CMP', start: 100, vol: 1.0 },  // Compute Futures
      { id: 'NVX', start: 240, vol: 1.3 },  // Chip Co (spiky)
      { id: 'DTA', start: 60,  vol: 1.1 },  // Data Corp
      { id: 'ALN', start: 150, vol: 0.45 }  // Safety ETF (calm)
    ]
  };

  // (Autopilot config removed in Phase 1 — automation dropped in favor of active decisions.)

  // ---- Cosmetics (earned, no pay-to-win) -------------------------------
  // unlock: {} always | {prestiges:n} | {singularities:n} | {ach:n owned}
  var COSMETICS = {
    orbs: [
      { id: 'orb_default', unlock: {} },
      { id: 'orb_cyan',    unlock: { modelGen: 1 } },   // ship v1
      { id: 'orb_gold',    unlock: { modelGen: 5 } },   // frontier territory
      { id: 'orb_crimson', unlock: { modelGen: 11 } }   // AGI
    ],
    themes: [
      { id: 'theme_default', unlock: {} },
      { id: 'theme_void',    unlock: { modelGen: 3 } },
      { id: 'theme_aurora',  unlock: { modelGen: 8 } }
    ]
  };

  // ====================================================================
  // GDD v3 — CONTINUOUS NO-RESET META (model generations, real-time processes)
  // ====================================================================

  // ---- Core resources / economy (continuous growth) -------------------
  // Generators now PRODUCE COMPUTE (the bottleneck). Money comes from your
  // deployed product (current model generation) × market share. See GAME-DESIGN.md §2-§4.
  var CORE = {
    // generator output (baseOut in GENERATORS) is COMPUTE/sec, not money.
    COMPUTE_PER_OUT: 1,
    TAP_COMPUTE: 2,            // compute per tap (overclock combo still multiplies)
    // product revenue: money/sec = REV_BASE * genRevenueMult * (1 + marketShare/100) * computeFactor
    REV_BASE: 0.15,           // tuned in P9
    REV_COMPUTE_FACTOR: 0.10, // (legacy) gentle log scaling
    REV_PER_COMPUTE: 0.5,     // money/sec per compute/sec of infra (product serves users ∝ compute)
    // Valuation = a believable "company worth": liquid cash + physical compute assets +
    // goodwill from PROVEN lifetime earnings, boosted by market dominance. Deliberately
    // NOT annualised run-rate × multiple — at compressed game-time that explodes valuation
    // to millions× the player's real cash. This keeps it in the same universe as cash.
    VAL_GOODWILL_MULT: 3,     // company worth ≈ 3× lifetime earnings (track record / IP / users)
    VAL_COMPUTE_ASSET: 1,     // each unit of compute capacity counts as a physical asset
    VAL_SHARE_PREMIUM: 2,     // market-dominance premium: ×(1 + share% × this/100); #1 ⇒ pride
    START_MONEY: 0
  };

  // ---- Model generations (replaces prestige). Forward-only ladder. ----
  // Each: trainSec (base real-time to train, shortened by researchers/boosts),
  // computeReq (compute STOCK spent to start training), revMult (PERMANENT product
  // revenue ×), share (market-share % granted on completion), id (i18n key).
  // ~month-long arc when paced with the real-time timers (balanced in P9).
  // trainSec is RAW real-time per generation (shortened by researchers/research/boost
  // via processSpeed ≈ up to ~3×). Tuned (P9) so the v1→AGI arc spans ~3–4 weeks of
  // real time for an engaged player (training is wall-clock — it advances offline too),
  // longer for casual play. Early gens are minutes (fast, satisfying onboarding); late
  // frontier gens are days→weeks (real lead-times, compressed). See BALANCE.md.
  var MODELGEN = [
    { id: 'g_v1',     trainSec: 60,       computeReq: 50,        revMult: 2.2,  share: 1 },   // 1 min
    { id: 'g_v2',     trainSec: 240,      computeReq: 400,       revMult: 2.4,  share: 2 },   // 4 min
    { id: 'g_v3',     trainSec: 900,      computeReq: 4e3,       revMult: 3.0,  share: 4 },   // 15 min — "ChatGPT moment"
    { id: 'g_v4',     trainSec: 3600,     computeReq: 4e4,       revMult: 3.5,  share: 6 },   // 1 h
    { id: 'g_v5',     trainSec: 14400,    computeReq: 4e5,       revMult: 4.0,  share: 8 },   // 4 h
    { id: 'g_v6',     trainSec: 54000,    computeReq: 4e6,       revMult: 5.0,  share: 10 },  // 15 h
    { id: 'g_front1', trainSec: 151200,   computeReq: 5e7,       revMult: 6.0,  share: 12 },  // ~1.75 d
    { id: 'g_front2', trainSec: 345600,   computeReq: 6e8,       revMult: 7.0,  share: 14 },  // 4 d
    { id: 'g_front3', trainSec: 691200,   computeReq: 8e9,       revMult: 9.0,  share: 16 },  // 8 d
    { id: 'g_proto',  trainSec: 1209600,  computeReq: 1e11,      revMult: 12.0, share: 18 },  // 14 d proto-AGI
    { id: 'g_agi',    trainSec: 1728000,  computeReq: 2e12,      revMult: 16.0, share: 22 }   // 20 d — AGI (win)
  ];

  // ---- Timed processes (the month-long engine) ------------------------
  var PROCESS = {
    // process speed = 1 + researchers-bonus(≤cap) + research-bonus(≤1.0) , × boost.
    // Capped (P9) so speedups are a meaningful reward but never collapse the month arc.
    RESEARCHER_SPEED_PER: 0.012, // each researcher = +1.2% process speed
    RESEARCHER_SPEED_CAP: 1.2,   // ≤ +120% from researchers
    RESEARCH_SPEED_CAP: 1.0,     // ≤ +100% from research projects
    OFFLINE_PROCESS: true,       // timers advance offline (capped by offline cap)
  };

  // ---- Parallel timed processes (the month-long engine, GAME-DESIGN.md §2/§7) --
  // Datacenter BUILD: money + real time → permanent compute capacity. Several
  // builds over the arc (real lead-time 6–12 months, compressed). Each adds BONUS
  // to the compute multiplier. cost/time escalate so later builds take hours→days.
  var DATACENTER = { baseCost: 1.2e4, costGrowth: 2.3, baseSec: 240, secGrowth: 1.55, bonus: 0.6 };
  // RESEARCH project: money + real time → permanent EFFICIENCY (faster processes +
  // more compute per unit). Repeatable ladder; escalates like builds.
  var RESEARCH2 = { baseCost: 6e3, costGrowth: 2.1, baseSec: 200, secGrowth: 1.5, speedBonus: 0.02, computeBonus: 0.06 };

  // ---- Researchers / talent -------------------------------------------
  var TALENT = {
    baseCost: 5e3,            // money cost of researcher #1
    growth: 1.15,             // cost(n) = baseCost * growth^hired
    UNLOCK_GEN: 2             // hiring opens once you ship v2
  };

  // ---- Finance: funding rounds (replaces twitchy market) --------------
  // Gated by MODEL GENERATION (genReq) — valuation grows too explosively to gate on.
  // Funding = a MEANINGFUL HEAD-START, never a game-skip. Cash injected = a few minutes
  // of your CURRENT income (self-scaling, so it can never trivialise the next stage —
  // you'd earn it in those minutes anyway). The real long-term value is `mult`: a
  // PERMANENT revenue boost. `secs` = seconds-of-current-income paid as the lump sum.
  var FUNDING = [
    { id: 'seed', genReq: 1, secs: 180, mult: 1.10 },   // ~3 min head-start
    { id: 'a',    genReq: 2, secs: 240, mult: 1.15 },   // ~4 min
    { id: 'b',    genReq: 4, secs: 300, mult: 1.20 },   // ~5 min
    { id: 'c',    genReq: 6, secs: 420, mult: 1.25 },   // ~7 min
    { id: 'ipo',  genReq: 8, secs: 600, mult: 1.40 }    // ~10 min
  ];

  // ---- Misc ------------------------------------------------------------
  var SETTINGS = {
    SAVE_KEY: 'singularity_inc_save_v1',
    SAVE_VERSION: 10,         // + executive / managing-director ladder (exec/mandate)
    AUTOSAVE_INTERVAL: 5,     // seconds
    TICK_MAX_DELTA: 0.25      // clamp huge frame deltas (tab switch handled by offline)
  };

  // 1 in-game "day" in real seconds — used by the decision engine's schedule/buff windows
  var DAY_SEC = 60;

  window.GAME_CONFIG = {
    DAY_SEC: DAY_SEC,
    GENERATORS: GENERATORS,
    MILESTONES: MILESTONES,
    UPGRADES: UPGRADES,
    MANAGERS: MANAGERS,
    PRESTIGE: PRESTIGE,
    CORE: CORE,
    MODELGEN: MODELGEN,
    PROCESS: PROCESS,
    DATACENTER: DATACENTER,
    RESEARCH2: RESEARCH2,
    TALENT: TALENT,
    FUNDING: FUNDING,
    UNLOCKS: UNLOCKS,
    RISK: RISK,
    TAP: TAP,
    OFFLINE: OFFLINE,
    ADS: ADS,
    ACHIEVEMENTS: ACHIEVEMENTS,
    WINDFALL: WINDFALL,
    ACTS: ACTS,
    RIVALS: RIVALS,
    RIVAL_SHARE_CAP: RIVAL_SHARE_CAP,
    ACQUIRE: ACQUIRE,
    RACE: RACE,
    ENDINGS: ENDINGS,
    TRUST: TRUST,
    CARDS: CARDS,
    DECISIONS: DECISIONS,
    DECISIONS_PACING: DECISIONS_PACING,
    EXECS: EXECS,
    EXECS_OFFLINE: EXECS_OFFLINE,
    MARKET: MARKET,
    COSMETICS: COSMETICS,
    EVENTS: EVENTS,
    COMBO: COMBO,
    INSIGHT: INSIGHT,
    BREAKTHROUGH: BREAKTHROUGH,
    GEN_CLASS: GEN_CLASS,
    TECH: TECH,
    ARTIFACTS: ARTIFACTS,
    ARTIFACT_SLOTS: ARTIFACT_SLOTS,
    ARTIFACT_SYNERGY: ARTIFACT_SYNERGY,
    SINGULARITY: SINGULARITY,
    SETTINGS: SETTINGS
  };
})();
